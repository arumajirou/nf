# Test package for nf_loto_webui extensions.
