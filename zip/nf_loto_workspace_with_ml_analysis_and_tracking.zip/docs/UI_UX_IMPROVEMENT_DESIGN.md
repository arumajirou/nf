# UI/UX改善調査と設計ドキュメント

## ドキュメント情報
- **バージョン**: 1.0.0
- **作成日**: 2025-11-13
- **対象**: NeuralForecast AutoML WebUI システム

---

## 1. UI/UX改善の目的

### 1.1 改善目標
1. **直感的な操作性**: 初心者でも迷わず使える
2. **効率的なワークフロー**: 最小クリック数での操作完了
3. **視覚的なフィードバック**: 進捗とステータスの明確な表示
4. **エラー予防**: 操作前の警告と確認
5. **レスポンシブデザイン**: 様々な画面サイズに対応

### 1.2 対象ユーザー
- **初心者**: 機械学習の基礎知識あり、時系列予測は初めて
- **中級者**: NeuralForecastの使用経験あり
- **上級者**: ハイパーパラメータチューニングの深い理解

---

## 2. ベストプラクティス調査

### 2.1 Streamlitの最新UI/UXパターン

#### ✅ 推奨パターン

**1. プログレッシブディスクロージャー**
```python
# 初心者向けにシンプルな設定を先に表示
with st.expander("⚙️ Quick Start (推奨)", expanded=True):
    preset = st.selectbox("設定プリセット", ["Balanced", "Fast", "Accurate"])
    
# 詳細設定は折りたたみで提供
with st.expander("🔧 Advanced Settings"):
    learning_rate = st.slider("Learning Rate", ...)
```

**2. ステップバイステップガイダンス**
```python
# ステッププロセスの明示
steps = ["📤 Data", "⚙️ Config", "🚀 Train", "📊 Results"]
current_step = st.session_state.get('step', 0)

# プログレスバー
st.progress(current_step / len(steps))
st.write(f"Step {current_step + 1}/{len(steps)}: {steps[current_step]}")
```

**3. リアルタイムバリデーション**
```python
# 入力値の即時検証とフィードバック
if dataset is not None:
    validation_results = validate_dataset(dataset)
    if validation_results.errors:
        st.error("❌ " + "\n".join(validation_results.errors))
    elif validation_results.warnings:
        st.warning("⚠️ " + "\n".join(validation_results.warnings))
    else:
        st.success("✅ Dataset validation passed")
```

**4. スマートデフォルト**
```python
# データセットに基づいた推奨設定の自動提案
recommended_h = auto_detect_horizon(dataset)
h = st.number_input(
    "Forecast Horizon", 
    value=recommended_h,
    help=f"推奨値: {recommended_h} (データセットから自動検出)"
)
```

### 2.2 カラーシステムとタイポグラフィ

#### カラーパレット
```python
COLORS = {
    # ステータス
    'success': '#28a745',
    'warning': '#ffc107',
    'error': '#dc3545',
    'info': '#17a2b8',
    
    # プライマリ
    'primary': '#0d6efd',
    'secondary': '#6c757d',
    
    # データビジュアライゼーション
    'chart_primary': '#4e73df',
    'chart_secondary': '#1cc88a',
    'chart_tertiary': '#f6c23e',
    
    # バックグラウンド
    'bg_light': '#f8f9fc',
    'bg_dark': '#2e3440',
}
```

#### タイポグラフィ階層
```python
# Streamlitマークダウンによるタイポグラフィ
st.markdown("# H1 - メインタイトル")           # 40px, bold
st.markdown("## H2 - セクションタイトル")     # 32px, bold
st.markdown("### H3 - サブセクション")        # 24px, bold
st.markdown("#### H4 - コンポーネントタイトル") # 18px, semi-bold
st.markdown("Body Text")                    # 16px, regular
```

### 2.3 情報アーキテクチャ

#### ナビゲーション構造
```
Dashboard (Home)
├── 📊 Overview
│   ├── Quick Stats
│   ├── Recent Experiments
│   └── System Status
│
├── 📤 Data Upload
│   ├── Upload Form
│   ├── Data Preview
│   └── Validation Results
│
├── ⚙️ Model Configuration
│   ├── Quick Start (Presets)
│   ├── Model Selection
│   ├── Hyperparameter Config
│   │   ├── Basic Settings
│   │   └── Advanced Settings
│   └── Configuration Summary
│
├── 🚀 Training
│   ├── Training Controls
│   ├── Real-time Progress
│   ├── Resource Monitor
│   │   ├── CPU/RAM Usage
│   │   ├── GPU/VRAM Usage
│   │   └── Disk I/O
│   └── Live Logs
│
├── 📈 Results
│   ├── Predictions Visualization
│   ├── Metrics Comparison
│   ├── Best Parameters
│   └── Export Options
│
└── 📜 History
    ├── Experiments List
    ├── Filter & Search
    ├── Detailed View
    └── Comparison Tool
```

---

## 3. 改善ポイント別設計

### 3.1 ダッシュボード (Home Page)

#### 🎯 改善目標
- システム全体の状態を一目で把握
- 最近の活動とクイックアクセス
- 重要な警告やアラート表示

#### 📐 レイアウト設計
```
┌────────────────────────────────────────────────────┐
│  🏠 Dashboard                         [User] [⚙️]   │
├────────────────────────────────────────────────────┤
│                                                    │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│  │  Total   │  │ Running  │  │Completed │       │
│  │  Exps    │  │  Exps    │  │  Today   │       │
│  │   42     │  │    3     │  │    5     │       │
│  └──────────┘  └──────────┘  └──────────┘       │
│                                                    │
│  ┌─────────────────────────────────────────────┐  │
│  │  📊 Recent Experiments                      │  │
│  ├─────────────────────────────────────────────┤  │
│  │  ○ NHITS_experiment_1      Running    70%  │  │
│  │  ✓ TFT_forecast_2         Completed  100% │  │
│  │  ✗ DLinear_test_3         Failed      0%  │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  ┌────────────────────┐  ┌────────────────────┐  │
│  │ 💻 System Status   │  │ ⚡ Quick Actions   │  │
│  ├────────────────────┤  ├────────────────────┤  │
│  │ CPU:  45% █████    │  │ [📤 Upload Data]   │  │
│  │ RAM:  8.2/16 GB    │  │ [🚀 New Training]  │  │
│  │ GPU:  75% ████████ │  │ [📊 View Results]  │  │
│  │ VRAM: 6.4/8 GB     │  │ [📜 History]       │  │
│  └────────────────────┘  └────────────────────┘  │
└────────────────────────────────────────────────────┘
```

#### 🔧 実装要点
```python
# メトリクスカード用のカスタムCSS
st.markdown("""
<style>
.metric-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 20px;
    border-radius: 10px;
    color: white;
    text-align: center;
}
.metric-value {
    font-size: 36px;
    font-weight: bold;
    margin: 10px 0;
}
.metric-label {
    font-size: 14px;
    opacity: 0.9;
}
</style>
""", unsafe_allow_html=True)

# メトリクスカード表示
col1, col2, col3 = st.columns(3)
with col1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Total Experiments</div>
        <div class="metric-value">{total_experiments}</div>
    </div>
    """, unsafe_allow_html=True)
```

### 3.2 データアップロード

#### 🎯 改善目標
- ドラッグ&ドロップの視覚的フィードバック
- 即座のデータ検証とプレビュー
- エラー修正の提案

#### 📐 レイアウト設計
```
┌────────────────────────────────────────────────────┐
│  📤 Data Upload                                    │
├────────────────────────────────────────────────────┤
│                                                    │
│  ┌─────────────────────────────────────────────┐  │
│  │   📁 Drag & Drop your file here             │  │
│  │   or click to browse                         │  │
│  │                                              │  │
│  │   Supported: CSV, Parquet, Excel             │  │
│  │   Max size: 500MB                            │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  ┌─────────────────────────────────────────────┐  │
│  │  ✓ Validation Results                       │  │
│  ├─────────────────────────────────────────────┤  │
│  │  ✅ Required columns present                 │  │
│  │  ✅ Data types correct                       │  │
│  │  ⚠️  Missing values in 3 rows (auto-filled) │  │
│  │  ✅ 1,234 rows × 3 columns                   │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  ┌─────────────────────────────────────────────┐  │
│  │  📊 Data Preview                            │  │
│  ├─────────────────────────────────────────────┤  │
│  │  [First 10 rows table]                      │  │
│  │  [Statistics summary]                       │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  [Cancel]                          [✓ Proceed →] │
└────────────────────────────────────────────────────┘
```

#### 🔧 実装要点
```python
# ファイルアップローダーのカスタマイズ
uploaded_file = st.file_uploader(
    "Choose a file",
    type=['csv', 'parquet', 'xlsx'],
    help="Upload time series data (unique_id, ds, y columns required)",
    accept_multiple_files=False
)

if uploaded_file:
    # ローディング表示
    with st.spinner('📥 Loading data...'):
        df = load_data(uploaded_file)
    
    # プログレスバー付き検証
    with st.spinner('🔍 Validating data...'):
        validation_result = validate_dataset(df)
    
    # 検証結果の視覚的表示
    display_validation_results(validation_result)
    
    # データプレビュー
    st.subheader("📊 Data Preview")
    st.dataframe(df.head(10), use_container_width=True)
    
    # 統計サマリー
    with st.expander("📈 Statistical Summary"):
        st.write(df.describe())
```

### 3.3 モデル設定

#### 🎯 改善目標
- 3段階の設定モード（Quick/Standard/Advanced）
- リアルタイムパラメータ検証
- 推奨設定の自動提案

#### 📐 レイアウト設計
```
┌────────────────────────────────────────────────────┐
│  ⚙️ Model Configuration                            │
├────────────────────────────────────────────────────┤
│                                                    │
│  Configuration Mode:                               │
│  ○ Quick Start  ● Standard  ○ Advanced            │
│                                                    │
│  ┌─────────────────────────────────────────────┐  │
│  │  Model Selection                            │  │
│  ├─────────────────────────────────────────────┤  │
│  │  [NHITS ▼]                                  │  │
│  │  Complexity: Moderate | Training: ~10min    │  │
│  │  💡 Recommended for: Medium-size datasets   │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  ┌─────────────────────────────────────────────┐  │
│  │  🎯 Basic Parameters                        │  │
│  ├─────────────────────────────────────────────┤  │
│  │  Horizon (h):        [24    ] periods      │  │
│  │  Backend:            [Optuna ▼]            │  │
│  │  Num Samples:        [Auto (50) ▼]         │  │
│  │  CPUs:               [4      ]             │  │
│  │  GPUs:               [1      ]             │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  ▼ Advanced Hyperparameters (Optional)            │
│  ┌─────────────────────────────────────────────┐  │
│  │  Learning Rate:      [Auto    ▼]           │  │
│  │  Batch Size:         [Auto    ▼]           │  │
│  │  Max Steps:          [1000    ]            │  │
│  │  ...                                        │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  ┌─────────────────────────────────────────────┐  │
│  │  📋 Configuration Summary                   │  │
│  ├─────────────────────────────────────────────┤  │
│  │  Model: NHITS                               │  │
│  │  Estimated Time: 10-15 minutes              │  │
│  │  Estimated Memory: ~4GB RAM, ~2GB VRAM      │  │
│  │  💡 Tip: Enable GPU for 3x faster training │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  [← Back]                        [Start Training →]│
└────────────────────────────────────────────────────┘
```

#### 🔧 実装要点
```python
# 設定モード選択
config_mode = st.radio(
    "Configuration Mode",
    ["Quick Start", "Standard", "Advanced"],
    horizontal=True,
    help="Quick: Preset configs | Standard: Common params | Advanced: Full control"
)

if config_mode == "Quick Start":
    preset = st.selectbox(
        "Choose Preset",
        ["Balanced", "Fast", "Accurate"],
        help="Balanced: Good for most cases\nFast: Quick results\nAccurate: Best performance"
    )
    config = load_preset(preset)
    
elif config_mode == "Standard":
    with st.form("standard_config"):
        model_name = st.selectbox("Model", MODEL_LIST)
        h = st.number_input("Forecast Horizon", value=24)
        backend = st.selectbox("Backend", ["Optuna", "Ray Tune"])
        num_samples = st.number_input("Number of Trials", value=50)
        
        # リソース設定
        col1, col2 = st.columns(2)
        with col1:
            cpus = st.slider("CPUs", 1, os.cpu_count(), 4)
        with col2:
            gpus = st.slider("GPUs", 0, torch.cuda.device_count(), 1)
        
        submitted = st.form_submit_button("✓ Confirm Configuration")
        
else:  # Advanced
    # 全パラメータの詳細設定
    with st.expander("🔧 Hyperparameter Search Space", expanded=True):
        st.write("Define custom search space for each parameter")
        
        # 動的にパラメータフォームを生成
        for param_name, param_def in model_params.items():
            if param_def['type'] == 'continuous':
                st.slider(
                    param_name,
                    min_value=param_def['min'],
                    max_value=param_def['max'],
                    value=(param_def['min'], param_def['max'])
                )
            elif param_def['type'] == 'categorical':
                st.multiselect(
                    param_name,
                    options=param_def['choices'],
                    default=param_def['choices']
                )

# リアルタイム見積もり
estimated_time = estimate_training_time(config)
estimated_memory = estimate_memory_usage(config)

st.info(f"""
⏱️ Estimated Training Time: {estimated_time} minutes  
💾 Estimated Memory: {estimated_memory['ram']} GB RAM, {estimated_memory['vram']} GB VRAM
""")
```

### 3.4 トレーニング進捗監視

#### 🎯 改善目標
- リアルタイムプログレス表示
- リソース使用状況の可視化
- 異常検知とアラート

#### 📐 レイアウト設計
```
┌────────────────────────────────────────────────────┐
│  🚀 Training in Progress...                        │
├────────────────────────────────────────────────────┤
│                                                    │
│  ┌─────────────────────────────────────────────┐  │
│  │  Trial 23/50 ████████░░░░░░░░░░ 46%        │  │
│  │  Current Loss: 0.234 | Best Loss: 0.189    │  │
│  │  Elapsed: 8m 34s | Remaining: ~10m         │  │
│  └─────────────────────────────────────────────┘  │
│                                                    │
│  ┌────────────────┐  ┌──────────────────────────┐ │
│  │ 💻 CPU         │  │ 📊 Loss History          │ │
│  │  45% ████░     │  │  [Interactive Chart]     │ │
│  │                │  │                          │ │
│  │ 💾 RAM         │  │                          │ │
│  │  8.2/16 GB     │  │                          │ │
│  │  █████░░░░░    │  │                          │ │
│  │                │  │                          │ │
│  │ 🎮 GPU 0       │  └──────────────────────────┘ │
│  │  85% ████████  │                              │
│  │                │  ┌──────────────────────────┐ │
│  │ 💿 VRAM        │  │ 📝 Live Logs             │ │
│  │  7.2/8 GB      │  │  [Trial 23] Testing...   │ │
│  │  ████████░     │  │  [Trial 22] Loss: 0.234  │ │
│  └────────────────┘  │  [Trial 21] Complete ✓   │ │
│                      └──────────────────────────┘ │
│                                                    │
│  [⏸️ Pause]  [⏹️ Stop]  [📊 View Partial Results] │
└────────────────────────────────────────────────────┘
```

#### 🔧 実装要点
```python
# リアルタイム更新用のプレースホルダー
progress_placeholder = st.empty()
metrics_placeholder = st.empty()
chart_placeholder = st.empty()
logs_placeholder = st.empty()

# トレーニングループ
for trial in range(num_samples):
    # プログレスバー更新
    progress_placeholder.progress(trial / num_samples)
    
    # メトリクス更新
    with metrics_placeholder.container():
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Current Trial", trial)
        with col2:
            st.metric("Best Loss", f"{best_loss:.4f}")
        with col3:
            st.metric("Remaining Time", format_time(remaining_time))
    
    # リソースモニタリング
    resource_data = monitor_resources()
    
    # チャート更新
    with chart_placeholder.container():
        fig = px.line(loss_history, title="Loss History")
        st.plotly_chart(fig, use_container_width=True)
    
    # ログ更新
    with logs_placeholder.container():
        for log in recent_logs[-5:]:
            st.text(log)
    
    time.sleep(0.1)  # 更新間隔
```

### 3.5 結果表示

#### 🎯 改善目標
- 複数の可視化オプション
- インタラクティブなグラフ
- エクスポート機能の充実

#### 📐 レイアウト設計
```
┌────────────────────────────────────────────────────┐
│  📈 Results - NHITS Experiment                     │
├────────────────────────────────────────────────────┤
│                                                    │
│  ┌──────────────────────────────────────────────┐  │
│  │  🎯 Performance Metrics                      │  │
│  ├──────────────────────────────────────────────┤  │
│  │  Best Loss:  0.1894    RMSE:  12.34         │  │
│  │  MAE:        10.23     MAPE:  5.67%          │  │
│  └──────────────────────────────────────────────┘  │
│                                                    │
│  Visualization Type:                               │
│  ● Time Series  ○ Residuals  ○ Distribution       │
│                                                    │
│  ┌──────────────────────────────────────────────┐  │
│  │  [Interactive Plotly Chart]                  │  │
│  │  - Actual vs Predicted                       │  │
│  │  - Zoom, Pan, Hover for details              │  │
│  │  - Toggle series visibility                  │  │
│  │                                              │  │
│  │  Series: [All ▼]  Date Range: [Custom ▼]    │  │
│  └──────────────────────────────────────────────┘  │
│                                                    │
│  ▼ Best Hyperparameters                            │
│  ┌──────────────────────────────────────────────┐  │
│  │  learning_rate:     0.0015                   │  │
│  │  batch_size:        64                       │  │
│  │  max_steps:         1000                     │  │
│  │  input_size:        24                       │  │
│  │  ...                                         │  │
│  └──────────────────────────────────────────────┘  │
│                                                    │
│  [📥 Export CSV]  [📊 Export Chart]  [💾 Save Model]│
└────────────────────────────────────────────────────┘
```

#### 🔧 実装要点
```python
# タブベースの可視化
tab1, tab2, tab3, tab4 = st.tabs([
    "📈 Time Series",
    "📊 Metrics",
    "🎯 Parameters",
    "📋 Details"
])

with tab1:
    # インタラクティブな時系列プロット
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=results['ds'],
        y=results['y'],
        name='Actual',
        mode='lines',
        line=dict(color='blue', width=2)
    ))
    fig.add_trace(go.Scatter(
        x=results['ds'],
        y=results['yhat'],
        name='Predicted',
        mode='lines',
        line=dict(color='red', width=2, dash='dash')
    ))
    
    fig.update_layout(
        title='Actual vs Predicted',
        xaxis_title='Date',
        yaxis_title='Value',
        hovermode='x unified',
        template='plotly_white'
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # フィルタリングオプション
    col1, col2 = st.columns(2)
    with col1:
        series_filter = st.multiselect(
            "Select Series",
            options=results['unique_id'].unique(),
            default=results['unique_id'].unique()[:3]
        )
    with col2:
        date_range = st.date_input(
            "Date Range",
            value=(results['ds'].min(), results['ds'].max())
        )

with tab2:
    # メトリクス比較
    metrics_df = pd.DataFrame({
        'Metric': ['RMSE', 'MAE', 'MAPE', 'R²'],
        'Value': [12.34, 10.23, 5.67, 0.92],
        'Baseline': [15.67, 13.45, 7.89, 0.85]
    })
    
    fig = px.bar(
        metrics_df,
        x='Metric',
        y=['Value', 'Baseline'],
        barmode='group',
        title='Metrics Comparison'
    )
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    # ベストパラメータ表示
    st.json(best_params)
    
    # パラメータ重要度
    param_importance = study.get_param_importances()
    fig = px.bar(
        x=list(param_importance.keys()),
        y=list(param_importance.values()),
        title='Parameter Importance'
    )
    st.plotly_chart(fig, use_container_width=True)

with tab4:
    # 詳細情報
    st.write("### Training Details")
    st.write(f"**Duration**: {duration} seconds")
    st.write(f"**Trials**: {num_trials}")
    st.write(f"**Best Trial**: #{best_trial}")
```

### 3.6 履歴管理

#### 🎯 改善目標
- 効率的な検索とフィルタリング
- 実験間の比較機能
- 一括操作のサポート

#### 📐 レイアウト設計
```
┌────────────────────────────────────────────────────┐
│  📜 Experiment History                              │
├────────────────────────────────────────────────────┤
│                                                    │
│  Search: [________________] 🔍                     │
│  Filters: [Status ▼] [Model ▼] [Date Range ▼]    │
│                                                    │
│  ☐ Select All  [Compare Selected]  [Export]       │
│                                                    │
│  ┌──────────────────────────────────────────────┐  │
│  │ ☐ NHITS_exp_1      ✓ Completed   2024-11-13 │  │
│  │    Loss: 0.189 | Duration: 12m | [View] [⋮]  │  │
│  ├──────────────────────────────────────────────┤  │
│  │ ☐ TFT_forecast_2   ● Running      2024-11-13 │  │
│  │    Progress: 67% | Remaining: 5m | [View] [⋮] │  │
│  ├──────────────────────────────────────────────┤  │
│  │ ☐ DLinear_test_3   ✗ Failed      2024-11-12 │  │
│  │    Error: OOM | [Details] [⋮]               │  │
│  └──────────────────────────────────────────────┘  │
│                                                    │
│  Showing 3 of 42 experiments  [1] [2] [3] ... [8]  │
└────────────────────────────────────────────────────┘
```

#### 🔧 実装要点
```python
# 検索とフィルター
col1, col2, col3 = st.columns([3, 1, 1])
with col1:
    search_query = st.text_input("Search experiments", "")
with col2:
    status_filter = st.multiselect(
        "Status",
        ["Running", "Completed", "Failed"],
        default=["Running", "Completed"]
    )
with col3:
    model_filter = st.multiselect(
        "Model",
        MODEL_LIST,
        default=MODEL_LIST
    )

# 実験リストの表示
experiments = load_experiments(
    search=search_query,
    status=status_filter,
    models=model_filter
)

# 選択チェックボックス
selected_experiments = []
for exp in experiments:
    col1, col2, col3, col4, col5 = st.columns([0.5, 3, 2, 2, 1])
    
    with col1:
        if st.checkbox("", key=f"select_{exp.id}"):
            selected_experiments.append(exp.id)
    
    with col2:
        st.write(f"**{exp.name}**")
    
    with col3:
        status_icon = {
            'completed': '✓',
            'running': '●',
            'failed': '✗'
        }
        st.write(f"{status_icon[exp.status]} {exp.status}")
    
    with col4:
        st.write(exp.created_at.strftime("%Y-%m-%d %H:%M"))
    
    with col5:
        if st.button("View", key=f"view_{exp.id}"):
            st.session_state['view_experiment'] = exp.id

# 比較機能
if len(selected_experiments) >= 2:
    if st.button("📊 Compare Selected"):
        show_comparison_view(selected_experiments)
```

---

## 4. アクセシビリティとユーザビリティ

### 4.1 キーボードナビゲーション
```python
# キーボードショートカット
st.markdown("""
<script>
document.addEventListener('keydown', function(e) {
    // Ctrl+S: セーブ
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        document.getElementById('save-button').click();
    }
    
    // Ctrl+Enter: 実行
    if (e.ctrlKey && e.key === 'Enter') {
        e.preventDefault();
        document.getElementById('run-button').click();
    }
});
</script>
""", unsafe_allow_html=True)
```

### 4.2 ツールチップとヘルプ
```python
# コンテキストヘルプ
st.number_input(
    "Forecast Horizon (h)",
    value=24,
    help="""
    予測期間の長さを指定します。
    
    推奨値:
    - 日次データ: 7-30日
    - 時間データ: 24-168時間
    - 月次データ: 6-12ヶ月
    
    ℹ️ より長い期間の予測は精度が低下する可能性があります。
    """
)
```

### 4.3 エラーメッセージとガイダンス
```python
# ユーザーフレンドリーなエラーメッセージ
try:
    result = train_model(config)
except OutOfMemoryError:
    st.error("""
    ❌ **メモリ不足エラー**
    
    推奨される対処法:
    1. ✅ バッチサイズを減らす (現在: 128 → 推奨: 64)
    2. ✅ input_sizeを減らす (現在: 96 → 推奨: 48)
    3. ✅ GPUメモリを増やす
    
    [自動調整する] [設定を変更する]
    """)
    
    if st.button("自動調整する"):
        config['batch_size'] = 64
        config['input_size'] = 48
        st.rerun()
```

---

## 5. レスポンシブデザイン

### 5.1 画面サイズ対応
```python
# モバイル/タブレット/デスクトップの検出
def get_screen_size():
    """JavaScriptでスクリーンサイズを取得"""
    screen_size = st_javascript("""
        window.innerWidth
    """)
    
    if screen_size < 768:
        return 'mobile'
    elif screen_size < 1024:
        return 'tablet'
    else:
        return 'desktop'

screen = get_screen_size()

# 画面サイズに応じたレイアウト
if screen == 'mobile':
    # 1カラムレイアウト
    st.metric("CPU", cpu_usage)
    st.metric("RAM", ram_usage)
    st.metric("GPU", gpu_usage)
elif screen == 'tablet':
    # 2カラムレイアウト
    col1, col2 = st.columns(2)
    with col1:
        st.metric("CPU", cpu_usage)
        st.metric("RAM", ram_usage)
    with col2:
        st.metric("GPU", gpu_usage)
else:
    # 3カラムレイアウト
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("CPU", cpu_usage)
    with col2:
        st.metric("RAM", ram_usage)
    with col3:
        st.metric("GPU", gpu_usage)
```

---

## 6. パフォーマンス最適化

### 6.1 キャッシング戦略
```python
# データローディングのキャッシュ
@st.cache_data(ttl=3600)
def load_dataset(file_path):
    """データセットを1時間キャッシュ"""
    return pd.read_csv(file_path)

# モデル特性のキャッシュ
@st.cache_resource
def load_model_catalog():
    """モデルカタログを永続キャッシュ"""
    return MODEL_CATALOG

# 実験履歴のキャッシュ
@st.cache_data(ttl=60)
def load_experiment_history():
    """実験履歴を1分キャッシュ"""
    return db.query_experiments()
```

### 6.2 遅延ローディング
```python
# 大きなデータのページネーション
page_size = 50
page_number = st.number_input("Page", min_value=1, value=1)

offset = (page_number - 1) * page_size
experiments = db.query_experiments(
    limit=page_size,
    offset=offset
)
```

---

## 7. 実装チェックリスト

### 7.1 必須実装項目
- [ ] プログレッシブディスクロージャー（Quick/Standard/Advanced）
- [ ] リアルタイムバリデーション
- [ ] スマートデフォルトと推奨値
- [ ] インタラクティブなプログレス表示
- [ ] リソース監視の可視化
- [ ] 複数タブでの結果表示
- [ ] 検索・フィルター機能
- [ ] 実験比較機能

### 7.2 推奨実装項目
- [ ] キーボードショートカット
- [ ] ダークモードサポート
- [ ] カスタムCSSテーマ
- [ ] エクスポート機能（CSV, JSON, Excel）
- [ ] 通知システム
- [ ] アンドゥ/リドゥ機能

### 7.3 将来の拡張項目
- [ ] ユーザー認証システム
- [ ] チーム共有機能
- [ ] テンプレート機能
- [ ] ワークフローオートメーション
- [ ] カスタムダッシュボード

---

## 8. テスト戦略

### 8.1 ユーザビリティテスト
```python
# A/Bテスト用の設定
if st.session_state.get('ab_test_group') == 'A':
    # バージョンA: シンプルなUI
    show_simple_ui()
else:
    # バージョンB: 詳細なUI
    show_detailed_ui()

# フィードバック収集
feedback = st.text_area("このUIについてのフィードバックをお願いします")
if st.button("送信"):
    save_feedback(feedback, version=st.session_state['ab_test_group'])
```

### 8.2 パフォーマンステスト
```python
# レンダリング時間の測定
import time

start_time = time.time()
render_dashboard()
render_time = time.time() - start_time

# 2秒以上かかる場合は警告
if render_time > 2.0:
    logger.warning(f"Slow render: {render_time:.2f}s")
```

---

## 9. ドキュメント

### 9.1 インラインヘルプ
- すべての設定項目にツールチップ
- 重要な用語にポップオーバー説明
- ステップバイステップガイドへのリンク

### 9.2 チュートリアル
- 初回ユーザー向けインタラクティブツアー
- ビデオチュートリアル
- サンプルプロジェクト

---

## 付録: UIコンポーネント ライブラリ

### カスタムコンポーネント集
```python
# components/custom_metrics.py
def metric_card(label, value, delta=None, color='primary'):
    """カスタムメトリクスカード"""
    st.markdown(f"""
    <div class="metric-card metric-{color}">
        <div class="metric-label">{label}</div>
        <div class="metric-value">{value}</div>
        {f'<div class="metric-delta">{delta}</div>' if delta else ''}
    </div>
    """, unsafe_allow_html=True)

# components/progress_ring.py
def progress_ring(value, max_value, size=100):
    """円形プログレスバー"""
    percent = (value / max_value) * 100
    return f"""
    <svg width="{size}" height="{size}">
        <circle ... />
        <text ...>{percent:.0f}%</text>
    </svg>
    """

# components/status_badge.py
def status_badge(status):
    """ステータスバッジ"""
    colors = {
        'running': 'blue',
        'completed': 'green',
        'failed': 'red',
        'pending': 'gray'
    }
    return f'<span class="badge badge-{colors[status]}">{status}</span>'
```

---

## まとめ

この設計ドキュメントに基づいて実装することで、以下を達成できます：

1. **直感的な操作性**: 3段階の設定モードで、初心者から上級者まで対応
2. **効率的なワークフロー**: ステップバイステップガイダンスで迷わず操作
3. **視覚的なフィードバック**: リアルタイムの進捗とリソース監視
4. **エラー予防**: 入力時の即時検証と明確なエラーメッセージ
5. **レスポンシブデザイン**: 様々なデバイスで快適に使用可能

**次のステップ**: この設計に基づいて、各コンポーネントを実装していきます。
