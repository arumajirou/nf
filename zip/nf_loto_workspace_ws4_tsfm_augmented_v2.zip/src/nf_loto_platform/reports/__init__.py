"""Utility package nf_reports for NeuralForecast MLOps extensions."""
