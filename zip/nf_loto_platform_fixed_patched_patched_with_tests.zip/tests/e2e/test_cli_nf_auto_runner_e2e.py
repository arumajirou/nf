import pytest


@pytest.mark.e2e
@pytest.mark.skip(reason="CLI E2E テストは外部依存が多いため手動で実施")
def test_cli_nf_auto_runner_e2e_placeholder():
    assert True
