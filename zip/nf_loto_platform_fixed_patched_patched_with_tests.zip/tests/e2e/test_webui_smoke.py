import pytest


@pytest.mark.e2e
@pytest.mark.skip(reason="Streamlit WebUI の自動 UI テストは未実装")
def test_webui_smoke_placeholder():
    assert True
