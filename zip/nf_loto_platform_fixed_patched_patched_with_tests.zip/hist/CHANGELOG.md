# CHANGELOG

## v0.1.1 (internal refactor snapshot)

- `nf_loto_platform.db.loto_pg_store` の import パスを修正  
  - `from db_config import ...` → `from .db_config import ...`  
  - `from loto_etl import build_df_final` → `from .loto_etl import build_df_final`
- `nf_loto_platform.db.setup_postgres` の import パスを修正  
  - `from postgres_manager import ...` → `from .postgres_manager import ...`  
  - `from db_config import DB_CONFIG` → `from .db_config import DB_CONFIG`
- `legacy/nf_loto_webui/src/data_access/loto_repository.py` をベースに  
  `nf_loto_platform.db.loto_repository` を新規追加
- `legacy/nf_loto_webui/src/logging/db_logger.py` をベースに  
  `nf_loto_platform.logging_ext.db_logger` を新規追加
- `nf_loto_platform.ml.model_runner` の import を現行パッケージ階層に合わせて修正  
  - `src.data_access.loto_repository` → `nf_loto_platform.db.loto_repository`  
  - `src.logging.db_logger` → `nf_loto_platform.logging_ext.db_logger`  
  - `src.monitoring.*` → `nf_loto_platform.monitoring.*`
- プロジェクトルートに `pyproject.toml` を追加（src レイアウト・依存関係を定義）
- `report/` ディレクトリを作成し、pytest HTML レポートのサンプルと運用ガイドを追加
- `hist/` ディレクトリを作成し、本 CHANGELOG とリファクタリング計画を追加



## v0.1.2 (test hardening & monitoring API) - 2025-11-14

- `nf_loto_platform.monitoring.prometheus_metrics` に `observe_run_error` を追加し、
  `nf_loto_platform.ml.model_runner` からの呼び出しと静的 import テストの両方が通るように調整
- `tests/monitoring/test_prometheus_metrics.py` を拡張し、公開 API 契約
  (`init_metrics_server`, `observe_run_start`, `observe_run_end`, `observe_run_error`, `observe_train_step`)
  を検査するテストを追加
- `tests/ml/test_model_runner_contract.py` を新規追加し、
  `run_loto_experiment` / `sweep_loto_experiments` エントリポイントと
  `LotoExperimentResult` データクラスの存在を検証
- `tests/logging_ext/test_db_logger_contract.py` を新規追加し、
  DB ロガーの公開関数 (`log_run_start`, `log_run_end`, `log_run_error`) の存在を確認する
  軽量な契約テストを実装
- `tests/db/test_loto_pg_store_contract_extra.py` を新規追加し、
  `COLS` / `TABLE_NAME` の整合性および主要ヘルパ関数群の存在を確認
- `tests/db/test_loto_repository_contract.py` を新規追加し、
  LOTO 系テーブルアクセス用のユーティリティ API
  (`get_connection`, `list_loto_tables`, `load_panel_by_loto`) の存在を検査
