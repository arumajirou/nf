\
    param(
        [string]$InstallDir = "$(Join-Path $PSScriptRoot 'TimeSeriesScientist')",
        [string]$DataPath   = "$(Join-Path $PSScriptRoot 'data\\sample_timeseries.csv')",
        [int]$NumSlices     = 4,
        [int]$Horizon       = 24,
        [string]$LlmModel   = "gpt-4o"
    )

    $ErrorActionPreference = "Stop"

    Write-Host "=== TimeSeriesScientist サンプル実行 ===" -ForegroundColor Cyan
    Write-Host "InstallDir : $InstallDir"
    Write-Host "DataPath   : $DataPath"
    Write-Host "NumSlices  : $NumSlices"
    Write-Host "Horizon    : $Horizon"
    Write-Host "LLM Model  : $LlmModel"
    Write-Host ""

    # 仮想環境の Python を特定
    $venvPath  = Join-Path $InstallDir ".venv"
    $pythonExe = Join-Path $venvPath "Scripts\\python.exe"

    if (-not (Test-Path $pythonExe)) {
        throw "仮想環境の python.exe が見つかりませんでした。先に setup_timeseriesscientist.ps1 を実行してください。"
    }

    # 作業ディレクトリを決める
    $agentDir = Join-Path $InstallDir "time_series_agent"
    if (Test-Path (Join-Path $agentDir "main.py")) {
        $workDir = $agentDir
    }
    elseif (Test-Path (Join-Path $InstallDir "main.py")) {
        $workDir = $InstallDir
    }
    else {
        throw "main.py が見つかりませんでした。TimeSeriesScientist のディレクトリ構造を確認してください。"
    }

    if (-not (Test-Path $DataPath)) {
        throw "指定された DataPath が存在しません: $DataPath"
    }

    Push-Location $workDir
    try {
        & $pythonExe "main.py" `
            "--data_path" $DataPath `
            "--num_slices" $NumSlices `
            "--horizon" $Horizon `
            "--llm_model" $LlmModel
    }
    finally {
        Pop-Location
    }

    Write-Host ""
    Write-Host "=== 実行完了 ===" -ForegroundColor Green
    Write-Host "結果は TimeSeriesScientist/time_series_agent/results 以下に出力されます。"
