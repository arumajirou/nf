\
    param(
        [string]$InstallDir = "$(Join-Path $PSScriptRoot 'TimeSeriesScientist')",
        [string]$PythonExe  = "python"
    )

    $ErrorActionPreference = "Stop"

    Write-Host "=== TimeSeriesScientist セットアップ開始 ===" -ForegroundColor Cyan
    Write-Host "InstallDir: $InstallDir"
    Write-Host "PythonExe : $PythonExe"
    Write-Host ""

    # 1. リポジトリのクローン
    if (-not (Test-Path $InstallDir)) {
        Write-Host "[1/4] GitHub から公式リポジトリをクローンします..." -ForegroundColor Yellow
        git clone https://github.com/Y-Research-SBU/TimeSeriesScientist.git $InstallDir
    }
    else {
        Write-Host "[1/4] InstallDir は既に存在します。git clone はスキップします。" -ForegroundColor Yellow
    }

    # 2. Python 仮想環境の作成
    $venvPath = Join-Path $InstallDir ".venv"
    if (-not (Test-Path $venvPath)) {
        Write-Host "[2/4] Python 仮想環境 (.venv) を作成します..." -ForegroundColor Yellow
        & $PythonExe -m venv $venvPath
    }
    else {
        Write-Host "[2/4] 既存の仮想環境 (.venv) を使用します。" -ForegroundColor Yellow
    }

    # 3. 仮想環境をアクティベート
    $activateScript = Join-Path $venvPath "Scripts\\Activate.ps1"
    if (-not (Test-Path $activateScript)) {
        throw "仮想環境の Activate.ps1 が見つかりませんでした: $activateScript"
    }

    Write-Host "[3/4] 仮想環境をアクティベートして依存ライブラリをインストールします..." -ForegroundColor Yellow

    & $activateScript

    # 4. requirements.txt の場所を決定
    $agentDir = Join-Path $InstallDir "time_series_agent"
    if (Test-Path (Join-Path $agentDir "requirements.txt")) {
        Set-Location $agentDir
    }
    elseif (Test-Path (Join-Path $InstallDir "requirements.txt")) {
        Set-Location $InstallDir
    }
    else {
        throw "requirements.txt が見つかりませんでした。TimeSeriesScientist のディレクトリ構造を確認してください。"
    }

    # pip をアップグレード
    Write-Host "pip をアップグレードします..." -ForegroundColor DarkCyan
    pip install --upgrade pip

    # 依存ライブラリ
    Write-Host "requirements.txt をインストールします..." -ForegroundColor DarkCyan
    pip install -r requirements.txt

    # オプション依存（README より）
    Write-Host "オプション依存 (prophet, tbats) をインストールします..." -ForegroundColor DarkCyan
    pip install prophet tbats

    Write-Host ""
    Write-Host "=== セットアップ完了 ===" -ForegroundColor Green
    Write-Host "公式 README に沿って、以下も確認してください:"
    Write-Host "  - OPENAI_API_KEY / GOOGLE_API_KEY の環境変数設定"
    Write-Host "  - dataset ディレクトリに自分の CSV を配置"
