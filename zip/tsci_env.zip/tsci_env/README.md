# TimeSeriesScientist 補助環境パッケージ

この ZIP は、公式リポジトリ **TimeSeriesScientist (TSci)** citeturn1view0 を Windows + PowerShell で簡単にセットアップして試すための補助ファイル集です。  
公式コードそのものは含まれておらず、PowerShell スクリプトが GitHub からクローンして環境構築を行います。

---

## 前提環境

- Windows 10 / 11
- PowerShell 5 以降（または PowerShell 7）
- Python 3.8 以上（公式 README 推奨）
- `git` コマンドが使えること
- OpenAI API キー（`gpt-4o` などを使うため）

---

## ファイル構成

```text
tsci_env/
  README.md                      このファイル
  setup_timeseriesscientist.ps1  環境構築スクリプト（クローン＋仮想環境＋依存ライブラリ）
  run_tsci_example.ps1           サンプルデータで TSci を一発実行するスクリプト
  config/
    tsci_example_config.json     例示用の設定ファイル（パラメータ参考用）
  data/
    sample_timeseries.csv        「date」「OT」列を持つサンプル時系列データ
```

---

## セットアップ手順（PowerShell）

1. この ZIP を任意のフォルダに展開する  
   例）`C:\work\tsci_env` に展開したとします。

2. PowerShell を開いてディレクトリ移動

   ```powershell
   Set-Location C:\work\tsci_env
   ```

3. 環境構築スクリプトを実行

   ```powershell
   .\setup_timeseriesscientist.ps1 -InstallDir .\TimeSeriesScientist
   ```

   - 初回は
     - GitHub から公式リポジトリをクローン
     - `TimeSeriesScientist\.venv` に Python 仮想環境を作成
     - `requirements.txt` といくつかの追加ライブラリをインストール
   - 2 回目以降は既存ディレクトリを検出してクローンをスキップします。

4. OpenAI API キーなどの環境変数を設定

   ```powershell
   # PowerShell セッション内に設定（例）
   $env:OPENAI_API_KEY = "sk-xxxx..."

   # 必要なら（任意）
   # $env:GOOGLE_API_KEY = "..." 
   ```

5. サンプルを実行してみる

   ```powershell
   .\run_tsci_example.ps1 `
     -InstallDir .\TimeSeriesScientist `
     -DataPath   .\data\sample_timeseries.csv `
     -NumSlices  4 `
     -Horizon    24 `
     -LlmModel   "gpt-4o"
   ```

   - `sample_timeseries.csv` は日次のダミーデータです。
   - 実際の利用時は、自分の CSV ファイル（`date` / `OT` 列を含む）パスを `-DataPath` に指定してください。
   - 実行が成功すると、`TimeSeriesScientist\time_series_agent\results\...` 以下に各種レポートと可視化が保存されます（公式 README に準拠）。

---

## 注意事項

- この環境は **公式実装のラッパー** にすぎません。研究や本番利用では、必ず公式リポジトリと論文の README / ドキュメントを確認してください。
- PowerShell スクリプトは、標準的な Windows 環境を想定した汎用的なものです。プロキシ環境や企業ネットワークでは `git clone` や `pip install` に追加設定が必要な場合があります。
- OpenAI API の利用料金やレート制限には注意してください。

---

## 公式リポジトリ・論文リンク

- GitHub: https://github.com/Y-Research-SBU/TimeSeriesScientist
- 論文: https://arxiv.org/abs/2510.01538
