# nf_loto_platform LLM拡張 アーキテクチャ設計書（サマリ）

新規パッケージ: llm, rag, tools, agents を追加し、既存レイヤに横付けする構成とする。
