# AutoMLAgent システムプロンプト（例）

nf_loto_platform 上で時系列実験を設計・実行するエージェント向けのプロンプトテンプレートです。
