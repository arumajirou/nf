# nf_loto_platform LLM拡張 モジュールインタフェース仕様（サマリ）

- llm.providers.LLMProvider
- rag.light_rag_client.LightRAGClient
- tools.{db_tools, ml_tools, report_tools}
- agents.{CoordinatorAgent, AutoMLAgent, ReportAgent}
