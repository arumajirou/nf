"""レポート関連ツール.

reports モジュールとの橋渡しを行い、エージェントが扱いやすい形式で返す。
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict


def generate_html_report(run_id: str) -> Path:
    """指定 run_id の結果を HTML レポートとして出力し、そのパスを返す."""
    from nf_loto_platform.reports.html_reporter import HtmlReporter  # 遅延 import
    reporter = HtmlReporter()
    output_path = reporter.generate(run_id)
    return Path(output_path)


def summarize_metrics(run_id: str) -> Dict[str, Any]:
    """指定 run_id の主要指標を dict で返す.

    NOTE: HtmlReporter もしくは別のメトリクス管理クラスから情報を取得するよう拡張すること。
    """
    from nf_loto_platform.reports.html_reporter import HtmlReporter  # 遅延 import
    reporter = HtmlReporter()
    meta = reporter.get_summary(run_id)
    return meta
