"""DB 関連ツール関数.

エージェントや LLM から既存の DB アクセス層を安全に叩くための薄いラッパ。
実行時にのみ psycopg2 / LotoRepository を import することで、開発環境の依存欠如による import エラーを防ぐ。
"""
from __future__ import annotations

from typing import Any, Dict
import pandas as pd


def get_recent_runs(limit: int = 20) -> pd.DataFrame:
    """nf_model_runs テーブルから直近 N 件の実験情報を取得する.

    NOTE: 実プロジェクト環境で LotoRepository 実装を提供していることが前提。
    """
    from nf_loto_platform.db.loto_repository import LotoRepository  # 遅延 import
    repo = LotoRepository()
    df = repo.get_recent_model_runs(limit=limit)
    return df


def get_run_detail(run_id: str) -> Dict[str, Any]:
    """run_id に紐づく実験詳細情報を取得する."""
    from nf_loto_platform.db.loto_repository import LotoRepository  # 遅延 import
    repo = LotoRepository()
    return repo.get_model_run_detail(run_id)
