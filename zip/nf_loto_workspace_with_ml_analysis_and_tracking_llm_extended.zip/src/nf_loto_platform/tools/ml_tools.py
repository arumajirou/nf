"""ML 実験実行ツール.

ml.model_runner をエージェント側から使いやすくするための薄いラッパ。
"""
from __future__ import annotations

from typing import Any, Dict, List


def run_experiment_from_spec(spec: Dict[str, Any]) -> str:
    """実験仕様 dict から run_loto_experiment を呼び出し、run_id を返す.

    NOTE: neuralforecast 等の重い依存は、実行時にのみ import する。
    """
    from nf_loto_platform.ml.model_runner import run_loto_experiment  # 遅延 import
    result = run_loto_experiment(**spec)
    if isinstance(result, dict) and "run_id" in result:
        return str(result["run_id"])
    raise RuntimeError("run_loto_experiment did not return a run_id in the expected format.")


def sweep_experiments_from_grid(grid_spec: Dict[str, Any]) -> List[str]:
    """パラメータグリッドから複数実験を実行し、run_id のリストを返す."""
    from nf_loto_platform.ml.model_runner import sweep_loto_experiments  # 遅延 import
    results = sweep_loto_experiments(**grid_spec)
    run_ids: List[str] = []
    for r in results:
        if isinstance(r, dict) and "run_id" in r:
            run_ids.append(str(r["run_id"]))
    return run_ids
