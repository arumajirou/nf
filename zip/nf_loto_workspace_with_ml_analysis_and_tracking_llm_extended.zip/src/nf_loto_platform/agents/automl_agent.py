"""AutoML エージェントのスケルトン.

agent-lightning による RL 部分は、環境準備後に実装を追加する。
"""
from __future__ import annotations

from typing import Callable, Dict, Any

from nf_loto_platform.llm.providers import LLMProvider


class AutoMLAgent:
    """時系列実験の候補提案と実行を行うエージェント."""

    def __init__(
        self,
        llm: LLMProvider,
        tools: Dict[str, Callable[..., Any]],
        rl_client: Any | None = None,
    ) -> None:
        self._llm = llm
        self._tools = tools
        self._rl = rl_client

    def suggest_and_run_experiments(self, task_spec: Dict[str, Any]) -> Dict[str, Any]:
        """タスク仕様を受け取り、ひとまず 1 本だけ実験を実行する簡易版.

        実運用では:
            - LLM による複数候補生成
            - agent-lightning による状態・行動・報酬の管理
        を追加する。
        """
        # ここでは例として固定的な spec を使う
        spec = task_spec.get("experiment_spec", {})
        run_experiment = self._tools.get("run_experiment_from_spec")  # type: ignore[assignment]
        if run_experiment is None:
            raise RuntimeError("run_experiment_from_spec tool is not provided.")
        run_id = run_experiment(spec)
        return {"run_id": run_id, "status": "submitted"}
