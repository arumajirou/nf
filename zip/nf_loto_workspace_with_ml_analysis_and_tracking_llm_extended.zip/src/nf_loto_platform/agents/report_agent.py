"""予測インサイトレポート生成エージェントのスケルトン."""
from __future__ import annotations

from typing import Callable, Dict, Any, List

from nf_loto_platform.llm.providers import LLMProvider


class ReportAgent:
    """run_id 単位の自然言語レポートを生成するエージェント."""

    def __init__(
        self,
        llm: LLMProvider,
        tools: Dict[str, Callable[..., Any]],
        rag_client: Any | None = None,
    ) -> None:
        self._llm = llm
        self._tools = tools
        self._rag = rag_client

    def generate_insight(self, run_id: str) -> str:
        """指定 run_id のインサイトテキストを生成する簡易版.

        実運用では:
            - summarize_metrics(run_id)
            - 必要に応じて過去レポートやドキュメントの RAG 検索
        を行い、その結果をコンテキストとして LLM に渡す。
        """
        summarize = self._tools.get("summarize_metrics")  # type: ignore[assignment]
        metrics: Dict[str, Any] | None = None
        if summarize is not None:
            metrics = summarize(run_id)
        metrics_text = "" if metrics is None else str(metrics)

        messages: List[Dict[str, str]] = [
            {"role": "system", "content": "You create human-readable reports about forecasting experiments."},
            {"role": "user", "content": f"実験 {run_id} のメトリクス要約: {metrics_text}\nこれを人間向けレポートにして。"},
        ]
        return self._llm.chat(messages)
