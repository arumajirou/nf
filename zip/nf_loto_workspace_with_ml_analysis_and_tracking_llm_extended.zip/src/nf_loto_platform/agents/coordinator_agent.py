"""LLM コパイロット用エージェントの簡易実装スケルトン."""
from __future__ import annotations

from typing import Callable, Dict, Any, List

from nf_loto_platform.llm.providers import LLMProvider


class CoordinatorAgent:
    """ユーザの質問を受け、ツール・RAG・LLM を組み合わせて回答を生成するエージェント."""

    def __init__(
        self,
        llm: LLMProvider,
        tools: Dict[str, Callable[..., Any]],
        rag_client: Any | None = None,
    ) -> None:
        self._llm = llm
        self._tools = tools
        self._rag = rag_client

    def answer_question(self, question: str) -> str:
        """最小限の実装: 質問をそのまま LLM に投げる.

        実運用では:
            - 質問内容から必要なツール/クエリを推論
            - DB/RAG からの結果をコンテキストに含めて LLM を呼び出す
        といったロジックを追加する。
        """
        messages: List[Dict[str, str]] = [
            {"role": "system", "content": "You are a helpful assistant for nf_loto_platform."},
            {"role": "user", "content": question},
        ]
        return self._llm.chat(messages)
