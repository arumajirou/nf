"""LightRAG 連携クライアントのスタブ実装.

実際の LightRAG 依存部分は、環境構築後に差し込む。
このファイルは、他モジュールからの import 先を固定する役割を持つ。
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, List, Iterable


class RAGError(RuntimeError):
    """RAG 処理中のエラー."""


@dataclass
class RetrievedChunk:
    content: str
    source: str
    score: float
    metadata: Dict[str, Any]


class LightRAGClient:
    """LightRAG との連携用ラッパ（スタブ）."""

    def __init__(self, settings: Dict[str, Any]) -> None:
        self.settings = settings
        self.index_dir = Path(settings.get("index_dir", "./data/rag_index"))

    def index_documents(self, sources: Iterable[Path]) -> None:
        """ドキュメントをインデックス構築対象として登録するスタブ.

        実装 TODO: LightRAG の index 機能を呼び出す。
        """
        # 実運用では LightRAG の API でインデックスを構築する。
        self.index_dir.mkdir(parents=True, exist_ok=True)
        # 今は何もしないスタブ。
        return None

    def query(self, question: str, top_k: int = 5) -> List[RetrievedChunk]:
        """LightRAG に対する検索スタブ.

        実装 TODO: LightRAG の query を呼び出して結果を RetrievedChunk にマッピングする。
        現状はダミー値を返す。
        """
        dummy = RetrievedChunk(
            content="RAG is not yet configured. This is a dummy answer.",
            source="dummy://rag_not_configured",
            score=0.0,
            metadata={"question": question},
        )
        return [dummy]
