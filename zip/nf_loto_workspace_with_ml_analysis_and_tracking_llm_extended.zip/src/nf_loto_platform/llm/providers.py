"""LLM プロバイダ抽象と簡易実装.

- LLMProvider: Protocol ベースの共通インタフェース
- OpenAIProvider: OpenAI 互換 API を叩く実装の雛形（実プロジェクト側で実装を埋める）
- DummyProvider: テスト用のスタブ実装
"""
from __future__ import annotations

from typing import Protocol, List, Dict, Any


class LLMError(RuntimeError):
    """LLM 呼び出しに関するエラー."""


class LLMProvider(Protocol):
    """LLM プロバイダ共通インタフェース."""

    def complete(self, prompt: str, **kwargs: Any) -> str:
        """1 プロンプト → 1 テキスト出力の補完を行う."""
        ...

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> str:
        """Chat 形式のやりとりを行う.

        messages: [{"role": "system"|"user"|"assistant", "content": "..."}, ...]
        """
        ...


class DummyProvider:
    """外部 API に依存しないテスト用 LLM 実装.

    実運用時には OpenAIProvider や LocalLLMProvider などと差し替える。
    """

    def complete(self, prompt: str, **kwargs: Any) -> str:
        return f"[DUMMY_COMPLETION] {prompt[:80]}"

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> str:
        last = messages[-1]["content"] if messages else ""
        return f"[DUMMY_CHAT_REPLY] {last[:80]}"
