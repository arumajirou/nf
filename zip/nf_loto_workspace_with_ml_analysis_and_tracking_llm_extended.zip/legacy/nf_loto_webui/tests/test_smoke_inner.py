def test_smoke():
    # 単純なスモークテスト。pytest が正しく起動・終了できるかの確認用。
    assert True
