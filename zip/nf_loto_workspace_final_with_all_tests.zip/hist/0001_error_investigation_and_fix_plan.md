# nf-loto-platform pytest エラー調査・改修計画 (実施ログ)

本ファイルは、pytest HTML レポートの解析に基づいて整理した
フェーズ 1〜4 の計画と、その実施内容を簡潔に記録したものです。

## フェーズ 1: モジュール import 破綻の解消

- `nf_loto_platform.monitoring.prometheus_metrics` に
  `observe_run_error` 関数を追加し、`model_runner` からの import を解決。
- `tests/monitoring/test_prometheus_metrics.py` を整備し、
  期待される公開 API 一式 (`init_metrics_server`, `observe_run_start`,
  `observe_run_end`, `observe_run_error`, `observe_train_step`) が
  存在することを確認するテストを実装。
- `tests/static/test_all_modules_importable.py` で
  `nf_loto_platform.ml.model_runner` を含む全モジュールが import 可能であることを
  確認する静的契約テストを維持。

## フェーズ 2: DB / SQL / モデル実行パイプラインの安定化

- `tests/nonfunctional/test_minimal_performance_smoke.py` および
  `tests/integration/test_training_with_mock_db.py` にて、
  実 DB や実 AutoModel に依存しない dummy 実装 + monkeypatch ベースの
  軽量パイプラインテストを構成。
- `loto_repository.load_panel_by_loto` / `automodel_builder.build_auto_model` /
  `build_neuralforecast` をテスト時にスタブ化し、
  `run_loto_experiment` が end-to-end で DataFrame とメタ情報を返す経路を確認。
- 実 DB / 実 AutoModel を前提とした「長時間テスト」は削り、
  代わりに mock DB + dummy AutoModel による 2 パターンの統合テストを追加
  （horizon=5 / horizon=3 のケース）。

## フェーズ 3: 性能テスト・非機能テストの整理

- `tests/nonfunctional/test_reproducibility_seed.py` で
  Python `random` / NumPy / (オプション) torch の種固定を検証。
- `tests/nonfunctional/test_minimal_performance_smoke.py` で
  dummy AutoModel と stubbed NeuralForecast を用いた軽量な性能スモークテストを実装。
- いずれも CI / ローカル環境で実行可能なサイズのデータ・計算量に制限し、
  「最低限 1 本は end-to-end に動く」ことを確認する位置づけとした。

## フェーズ 4: E2E / WebUI / パイプラインまわりのテスト拡充と skip 解消

- `src/nf_loto_platform/pipelines/training_pipeline.py`
  - `run_legacy_nf_auto_runner(base_root: Path | None = None)` へシグネチャを拡張し、
    テストから任意のディレクトリをルートとして指定できるように変更。
- `tests/pipelines/test_training_pipeline.py`
  - legacy runner が存在しない場合に `RunError` となるケースと、
    ダミーの `nf_auto_runner_full.py` を用意した場合に正常終了するケースの
    2 本のテストを実装。
- `tests/e2e/test_cli_nf_auto_runner_e2e.py`
  - pytest.skip を廃止し、tmp_path 配下にダミーの legacy runner を生成して
    `run_legacy_nf_auto_runner` を 1 周させる E2E スモークテストを実装。
- `src/nf_loto_platform/webui/__init__.py`
  - `is_webui_available()` ヘルパー関数を実装し、Streamlit が存在するかどうかを
    import ベースで簡易判定するラッパーを追加。
- `tests/webui/test_webui_placeholder.py` / `tests/e2e/test_webui_smoke.py`
  - それぞれ webui モジュールの API が存在し bool を返すことを確認するテストに置き換え、
    skip を解消。
- `src/nf_loto_platform/features/__init__.py`
  - パネルデータにラグ特徴量を追加する `add_lag_feature` を実装。
- `tests/features/test_features_placeholder.py` / `tests/integration/test_feature_pipeline_integration.py`
  - 上記 `add_lag_feature` を用いたユニットテスト / 小さな統合テストを実装し、
    features 系のプレースホルダテストを本実装に変更。

## skip 解消の概要

- 次のテストファイルから明示的な `@pytest.mark.skip` / `pytest.skip` を撤去し、
  実行可能なテストケースに差し替えた。
  - `tests/e2e/test_cli_nf_auto_runner_e2e.py`
  - `tests/e2e/test_webui_smoke.py`
  - `tests/features/test_features_placeholder.py`
  - `tests/integration/test_feature_pipeline_integration.py`
  - `tests/pipelines/test_training_pipeline.py`
  - `tests/webui/test_webui_placeholder.py`
- `tests/static/test_all_modules_importable.py` では
  `PKG_ROOT.rglob("*.py")` の結果から `__pycache__` 配下を事前に除外することで、
  実行時の `pytest.skip("cache directory")` を廃止しつつ、
  「全モジュール import 可能」という契約テストを維持。

## 今後の拡張余地

- DB ダイアレクト (PostgreSQL / SQLite) ごとの SQL プレースホルダ戦略の明示化。
- WebUI 実装（Streamlit アプリ本体）との結合テストを別レイヤとして追加。
- CI でのテストプロファイル（unit / integration / nonfunctional / e2e）の
  実行ポリシーを `TEST_PLAN.md` に追記。
