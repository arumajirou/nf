from nf_loto_platform.pipelines.training_pipeline import run_legacy_nf_auto_runner

if __name__ == "__main__":
    run_legacy_nf_auto_runner()
