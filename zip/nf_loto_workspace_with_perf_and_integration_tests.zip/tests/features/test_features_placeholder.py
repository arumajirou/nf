import pytest


@pytest.mark.skip(reason="features モジュールの詳細実装が未移行のためプレースホルダ")
def test_features_placeholder():
    assert True
