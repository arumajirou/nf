"""Utility package nf_metadata for NeuralForecast MLOps extensions."""
