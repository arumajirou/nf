# 🚀 NeuralForecast パラメータ抽出・PostgreSQL統合ツール

NeuralForecastモデルから全パラメータを抽出し、PostgreSQLデータベースに自動保存するツールキットです。

## ✨ 主な機能

- ✅ **完全な抽出**: モデル、PKL、CKPT、JSON、YAMLから全パラメータを抽出
- ✅ **PostgreSQL統合**: カテゴリごとにテーブルを自動作成
- ✅ **個別ファイル保存**: 処理中断対策として各ステップごとに保存
- ✅ **柔軟な出力**: CSV、Excel、JSON、PostgreSQL対応
- ✅ **堅牢なエラーハンドリング**: 詳細なログとエラー処理

## 📦 ファイル構成

```
neuralforecast_postgres_toolkit/
├── neuralforecast_extractor_postgres.py  # メインスクリプト
├── postgres_manager.py                    # PostgreSQL操作クラス
├── db_config.py                          # データベース設定
├── setup_postgres.py                     # セットアップツール
├── usage_examples.py                     # 使用例コード
├── requirements.txt                      # 依存パッケージ
├── QUICKSTART.md                         # クイックスタート（5分）
├── INSTALL.md                            # 詳細インストール手順
└── README_USAGE.md                       # 完全なドキュメント
```

## ⚡ クイックスタート

### 1. インストール

```bash
pip install -r requirements.txt
```

### 2. データベース設定

`db_config.py`を編集:

```python
DB_CONFIG = {
    'password': 'your_password',  # ← 変更
}
```

### 3. 実行

```python
from neuralforecast_extractor_postgres import NeuralForecastExtractor

MODEL_DIR = r"C:\path\to\your\model"
extractor = NeuralForecastExtractor(MODEL_DIR)
results = extractor.run_full_extraction(save_to_postgres=True)
```

詳細は [QUICKSTART.md](QUICKSTART.md) を参照してください。

## 📊 出力形式

### ファイル出力

- **CSV**: 縦持ち・横持ち形式
- **Excel**: 複数シート（パラメータ、ソース）
- **JSON**: 生データ、ステップごとの結果

### PostgreSQL出力

カテゴリごとにテーブルを自動作成:

| カテゴリ | テーブル名 | 内容 |
|---------|-----------|------|
| A_model | nf_model | モデル属性 |
| D_hparams | nf_hparams | ハイパーパラメータ |
| C_config | nf_config | 設定情報 |
| F_pkl | nf_pkl | PKLファイル |

## 📖 ドキュメント

- **[QUICKSTART.md](QUICKSTART.md)**: 5分で始める
- **[INSTALL.md](INSTALL.md)**: 詳細なインストール手順
- **[README_USAGE.md](README_USAGE.md)**: 完全な使い方ガイド
- **[usage_examples.py](usage_examples.py)**: サンプルコード

## 🔧 使用例

### 基本的な使い方

```python
from neuralforecast_extractor_postgres import NeuralForecastExtractor

MODEL_DIR = r"C:\path\to\your\model"
extractor = NeuralForecastExtractor(MODEL_DIR)
results = extractor.run_full_extraction(save_to_postgres=True)
```

### ステップごとの実行

```python
extractor = NeuralForecastExtractor(MODEL_DIR)
extractor.scan_files()
extractor.load_model()
extractor.extract_model_params()
extractor.extract_pkl_params()
extractor.create_dataframes()
extractor.save_all_to_files()
extractor.save_to_postgres()
```

### データフィルタリング

```python
from neuralforecast_extractor_postgres import filter_params_by_category, search_params

# カテゴリでフィルタ
model_params = filter_params_by_category(df_long, 'model')
hparams = filter_params_by_category(df_long, 'hparams')

# キーワード検索
learning_params = search_params(df_long, 'learning')
```

## 🛠️ セットアップツール

```bash
# 接続テスト
python setup_postgres.py test

# テーブル情報表示
python setup_postgres.py info

# フルセットアップ
python setup_postgres.py setup
```

## 💡 PostgreSQLなしで使用

```python
# PostgreSQL保存をスキップ
results = extractor.run_full_extraction(save_to_postgres=False)
```

ファイル出力のみが生成されます。

## 🐛 トラブルシューティング

### PostgreSQL接続エラー

```bash
# サービスを再起動
Restart-Service postgresql-x64-17

# 接続テスト
python setup_postgres.py test
```

### モジュールエラー

```bash
# psycopg2のインストール
pip install psycopg2-binary

# NeuralForecastのインストール
pip install neuralforecast
```

詳細は [INSTALL.md](INSTALL.md) を参照してください。

## 📋 システム要件

- Python 3.8以降
- PostgreSQL 12以降（オプション）
- メモリ: 4GB以上（推奨8GB以上）

## 🔄 更新履歴

### v2.0.0 (2025-01-11)
- PostgreSQL統合機能の追加
- 個別ファイル保存機能の追加
- エラーハンドリングの強化
- 段階的実行機能の追加
- 詳細なドキュメントの追加

## 📝 ライセンス

MIT License

## 🤝 貢献

バグ報告や機能リクエストは、Issueを作成してください。

## 📞 サポート

問題が解決しない場合:

1. [INSTALL.md](INSTALL.md)でトラブルシューティングを確認
2. `setup_postgres.py test`で接続テスト
3. エラーメッセージ全文を確認

---

**作成者**: AI Assistant  
**作成日**: 2025-01-11  
**バージョン**: 2.0.0
#   s o n n e t  
 