import pytest


@pytest.mark.integration
@pytest.mark.skip(reason="mock DB を使った学習フロー統合テストは今後追加予定")
def test_training_with_mock_db_placeholder():
    assert True
