import pytest


@pytest.mark.integration
@pytest.mark.skip(reason="DB や特徴量パイプラインの結合テストは別途環境を整えてから実装")
def test_feature_pipeline_integration_placeholder():
    assert True
