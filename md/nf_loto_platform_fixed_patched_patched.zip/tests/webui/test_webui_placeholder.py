import pytest


@pytest.mark.skip(reason="WebUI 用ヘルパーモジュールの実装に合わせてテストを追加予定")
def test_webui_placeholder():
    assert True
