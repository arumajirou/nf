import pytest


@pytest.mark.nonfunctional
@pytest.mark.slow
@pytest.mark.skip(reason="性能スモークテストは別途しきい値を決めてから実装")
def test_minimal_performance_smoke_placeholder():
    assert True
