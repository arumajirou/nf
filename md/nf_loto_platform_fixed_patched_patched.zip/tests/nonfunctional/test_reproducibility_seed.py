import pytest


@pytest.mark.nonfunctional
@pytest.mark.skip(reason="再現性テストは実モデルとデータが揃ってから実装")
def test_reproducibility_seed_placeholder():
    assert True
