import importlib


def test_prometheus_metrics_module_present():
    spec = importlib.util.find_spec("nf_loto_platform.monitoring.prometheus_metrics")
    assert spec is not None
