# CHANGELOG

## v0.1.1 (internal refactor snapshot)

- `nf_loto_platform.db.loto_pg_store` の import パスを修正  
  - `from db_config import ...` → `from .db_config import ...`  
  - `from loto_etl import build_df_final` → `from .loto_etl import build_df_final`
- `nf_loto_platform.db.setup_postgres` の import パスを修正  
  - `from postgres_manager import ...` → `from .postgres_manager import ...`  
  - `from db_config import DB_CONFIG` → `from .db_config import DB_CONFIG`
- `legacy/nf_loto_webui/src/data_access/loto_repository.py` をベースに  
  `nf_loto_platform.db.loto_repository` を新規追加
- `legacy/nf_loto_webui/src/logging/db_logger.py` をベースに  
  `nf_loto_platform.logging_ext.db_logger` を新規追加
- `nf_loto_platform.ml.model_runner` の import を現行パッケージ階層に合わせて修正  
  - `src.data_access.loto_repository` → `nf_loto_platform.db.loto_repository`  
  - `src.logging.db_logger` → `nf_loto_platform.logging_ext.db_logger`  
  - `src.monitoring.*` → `nf_loto_platform.monitoring.*`
- プロジェクトルートに `pyproject.toml` を追加（src レイアウト・依存関係を定義）
- `report/` ディレクトリを作成し、pytest HTML レポートのサンプルと運用ガイドを追加
- `hist/` ディレクトリを作成し、本 CHANGELOG とリファクタリング計画を追加
