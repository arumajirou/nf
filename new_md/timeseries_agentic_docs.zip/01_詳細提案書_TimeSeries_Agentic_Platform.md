# 01. 詳細提案書 — 自律的時系列予測研究プラットフォーム

## 1. 文書情報

- 文書名: 自律的時系列予測研究プラットフォーム 詳細提案書
- 作成日: 2025-11-17
- 版数  : 0.1（ドラフト）
- 作成者: （記入欄）

## 2. 背景

組織内には、売上・トラフィック・IoT センサ・アプリケーションログなど、多種多様な時系列データが蓄積されている。  
一方で、時系列予測・異常検知・因果推論の高度なユースケースを支えるためには、

- モデル・ライブラリ・フレームワークの乱立
- 評価指標やベンチマークの不統一
- 実験・学習結果およびリソース情報の属人管理
- モデル選択・ハイパーパラメータ調整の手作業依存
- ドメイン知識・文脈を踏まえた解釈の不足

といった課題が存在している。

近年は、Chronos / TimesFM / Moirai / Lag-Llama などの **Time Series Foundation Model (TSFM)**、  
および TimeSeriesScientist, TimeCopilot, Argos, anomaly-agent に代表される  
**LLM 駆動のエージェント型時系列フレームワーク**が登場しており、  
時系列分析のワークフロー全体を自律化・半自律化する基盤を構築する好機となっている。

## 3. 目的

本提案書は、以下を主目的とする。

1. PostgreSQL 上の任意テーブルから時系列データを取得し、
2. 伝統的統計モデル・機械学習モデル・TSFM・エージェント型フレームワークを横断的に活用し、
3. 予測値・異常検知結果・因果推論結果を一元管理するとともに、
4. CPU / GPU / IO / RAM / VRAM /学習時間などのリソース・性能情報を構造化して蓄積し、
5. 大規模な自律的時系列研究・運用環境を実現する

ための **プラットフォーム構想および開発計画**を示す。

## 4. システムコンセプト

### 4.1 コンセプト

- **「時系列の CI/CD + MLOps + AgentOps を一体化」した研究・実験基盤**
- DB からテーブル名を指定するだけで、
  - 前処理
  - 特徴量生成
  - モデル探索・アンサンブル
  - リソース・性能計測
  - 結果の可視化・解釈
  を自動的に実行し、結果を DB にメタデータとして記録する。

- 上位レイヤでは LLM エージェントが、
  - 「来月の売上予測と、主要ドライバを教えて」
  - 「最近の異常検知結果と、誤検知が多いルールを一覧して」
  のような自然言語クエリを受け、  
  背後で TimeCopilot / TimeSeriesScientist / Argos / anomaly-agent などを組み合わせて実行する。

### 4.2 全体アーキテクチャ（概念図）

```mermaid
flowchart LR
    subgraph DB[PostgreSQL]
        TBL[(業務テーブル)]
        META[(メタデータスキーマ)]
    end

    UI[LLM チャット UI / API] --> AGENT[時系列エージェント Orchestrator]

    AGENT --> PIPE[自動時系列パイプライン]
    PIPE -->|SQL/ORM| TBL

    subgraph PIPELINE[時系列パイプライン層]
        PRE[前処理・特徴量生成
(tsfel/temporian/tsflex/seglearn)]
        SEL[モデル選択
(TimeCopilot / TSci / AutoGluon)]
        TRAIN[学習・推論
(Darts/sktime/GluonTS/
Nixtla/neuralforecast/Merlion/TSFM)]
        EVAL[評価・ベンチマーク
(BasicTS/TFB/gift-eval/TS-Lib)]
        ENS[アンサンブル・メタ学習]
        CAUSAL[因果推論
(PyWhy/causal-learn + TS 特化拡張)]
        ANOM[異常検知
(Merlion/Argos/anomaly-agent)]
    end

    PIPE --> PROF[リソース・性能計測
(psutil/nvidia-smi/profiler)]

    PROF --> META
    EVAL --> META
    ENS --> META
    CAUSAL --> META
    ANOM --> META
```

## 5. スコープ

### 5.1 本フェーズで実現する範囲

1. **DB 連携基盤**
   - 指定された PostgreSQL テーブルから時系列データを取得する汎用インタフェース
   - メタデータ用スキーマ（実験・モデル・リソース等）の設計・実装

2. **モデル実行基盤（コアセット）**
   - Nixtla スタック（statsforecast/neuralforecast/mlforecast）
   - Darts, sktime, GluonTS, Merlion
   - 主要 TSFM のラッパー
     - amazon/chronos-2, chronos-t5 系
     - google/timesfm 系
     - ibm-granite/granite-timeseries-ttm-r2
     - time-series-foundation-models/Lag-Llama
     - Salesforce/moirai

3. **エージェント層（MVP）**
   - TimeCopilot / TimeSeriesScientist の組み込み PoC
   - Argos / anomaly-agent を用いた異常検知エージェント PoC
   - 予測タスク用 LLM プロンプトテンプレートとツール呼び出し設計

4. **ベンチマーク・評価基盤**
   - BasicTS / TFB / gift-eval / Time-Series-Library を用いた統一評価パイプライン
   - 評価結果の DB 蓄積と比較ビュー

5. **リソース・性能計測**
   - モデル学習・推論時の CPU/GPU/RAM/VRAM/IO/スループットを計測し DB 保存
   - モデル別・タスク別のコスト/精度トレードオフ分析が可能な設計

### 5.2 スコープ外（本提案時点）

- 大規模分散学習クラスタの構築自体（K8s, Ray, Spark など）は参考設計に留める
- 組織固有の認証・権限基盤との完全統合
- 完全フルマネージドな SaaS 製品化

## 6. 想定ユースケース

### 6.1 予測ユースケース

- 売上 / 需要予測（SKU × 店舗 × 日次）
- トラフィック予測（サービス別 QPS, レイテンシ）
- エネルギー消費予測（ビル・設備単位）

### 6.2 異常検知ユースケース

- サービス監視（メトリクス異常）
- IoT センサ異常（異常振動、温度異常など）
- 財務データの異常パターン検出

### 6.3 因果推論ユースケース

- 施策 A/B テストの効果推定
- 外生変数（キャンペーン・価格変更・天候）の影響度定量化
- 制御指標設計のための因果グラフ推定

## 7. 非機能要件（抜粋）

- **拡張性**: 新しいライブラリ・モデルをプラグイン的に追加可能であること
- **再現性**: すべての実験は DB のメタ情報から再実行可能であること
- **追跡可能性**: 予測結果・異常検知結果が、どのデータ・前処理・モデル・ハイパラ・リソース条件で得られたか追跡可能であること
- **自律性**: LLM エージェントがモデル候補選定・評価・アンサンブルを自律的に行えること
- **可観測性**: コスト・精度・安定性を俯瞰できるダッシュボードが構築可能であること

## 8. 開発方針

1. **MVP 優先**:  
   まずは「任意の psql テーブルから 1 クリックでマルチモデル予測＋結果メタデータ保存」が可能なコアを構築する。

2. **プラグインアーキテクチャ**:  
   モデルラッパ・ベンチマーク・エージェントを Plugin/Adapter パターンで実装し、  
   ライブラリ更新や TSFM 追加に柔軟に対応できるようにする。

3. **Infrastructure as Code / Config as Data**:  
   DVC / Hydra / Pydantic 等を活用し、実験構成をコード＋設定ファイルとして管理する。

4. **LLM 利用の安全設計**:  
   外部 API 利用時のコスト管理・ログ管理を行い、  
   重要判断（本番反映など）は人間のレビューを必須とするガードレールを設計する。

## 9. 想定ロードマップ（例）

```mermaid
gantt
    dateFormat  YYYY-MM-DD
    title       ロードマップ（例）

    section フェーズ1: コア基盤
    要件定義・詳細設計          :done,   des1, 2025-11-01, 2025-12-15
    DB スキーマ実装              :active, db1,  2025-12-01, 2026-01-15
    コアパイプライン (Nixtla/Darts/sktime) : db2,  2025-12-15, 2026-02-15

    section フェーズ2: TSFM / ベンチマーク
    TSFM ラッパ実装              : tsfm1, 2026-02-01, 2026-03-15
    BasicTS/TFB/gift-eval 連携   : bench1,2026-02-15, 2026-04-01

    section フェーズ3: エージェント層
    TimeCopilot/TSci PoC         : ag1,   2026-03-01, 2026-04-15
    Argos/anomaly-agent 連携     : ag2,   2026-03-15, 2026-05-01

    section フェーズ4: 安定化・高度化
    ダッシュボード・可視化      : vis1,  2026-04-01, 2026-05-15
    チューニング・運用設計      : op1,   2026-05-01, 2026-06-01
```

## 10. 期待効果

- モデル・ライブラリを横断した **公平な比較・評価** が可能になる。
- 実験の設定・結果・リソース情報を RDB 上で一括管理することで、  
  **大規模かつ再現性の高い研究・運用** を実現できる。
- LLM エージェントにより、非専門家であっても自然言語で  
  **高度な時系列分析を対話的に実行・理解** できるようになる。
