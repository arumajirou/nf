# 03. 詳細機能設計仕様書 — 自律的時系列予測研究プラットフォーム

## 1. アーキテクチャ概要

```mermaid
graph TD
    A[LLM チャット UI / API] --> B[Agent Orchestrator]

    subgraph C[Application Layer]
        B --> C1[Experiment Service]
        B --> C2[Forecast Service]
        B --> C3[Anomaly Service]
        B --> C4[Causal Service]
    end

    subgraph D[Pipeline Layer]
        C1 --> D1[Data Ingestion]
        C2 --> D2[Model Runner]
        C3 --> D3[Anomaly Pipeline]
        C4 --> D4[Causal Pipeline]
    end

    subgraph E[Integration Layer]
        D1 --> E1[DB Adapter (PostgreSQL)]
        D2 --> E2[TS Libraries Adapter]
        D3 --> E3[Agentic AD Adapter]
        D4 --> E4[PyWhy Adapter]
    end

    subgraph F[Persistence Layer]
        E1 --> F1[(業務 DB)]
        E2 --> F2[(メタデータ DB)]
        E3 --> F2
        E4 --> F2
    end
```

## 2. モジュール設計

### 2.1 Data Ingestion モジュール

- クラス: `PostgresTimeSeriesLoader`
- 責務:
  - 指定された `schema_name`, `table_name`, `time_column`, `target_column`, `id_columns` を元に SQL を組み立て
  - チャンク読み込み・型変換・インデックス設定を行う

- 擬似インタフェース:

```python
@dataclass
class TableSpec:
    schema: str
    table: str
    time_column: str
    target_column: str
    id_columns: list[str] | None = None

class PostgresTimeSeriesLoader:
    def __init__(self, conn_params: dict): ...
    def infer_schema(self, schema: str, table: str) -> dict: ...
    def load(self, spec: TableSpec) -> "TimeSeriesDataset": ...
```

### 2.2 Pipeline Orchestrator

- クラス: `TimeSeriesPipeline`
- 責務:
  - 前処理 → 特徴量 → モデル学習 → 予測 → 評価 → 保存までを一気通貫で実行
  - 実行中にリソース計測モジュールをフックする

```python
class TimeSeriesPipeline:
    def __init__(self, config: PipelineConfig, resource_profiler: ResourceProfiler): ...
    def run(self, dataset: TimeSeriesDataset) -> PipelineResult: ...
```

### 2.3 Model Adapter 層

- 抽象クラス: `BaseModelAdapter`
- 具体クラス例:
  - `NixtlaNeuralForecastAdapter`
  - `DartsAdapter`
  - `SktimeAdapter`
  - `GluonTSAdapter`
  - `MerlionAdapter`
  - `ChronosHFAdapter`
  - `TimesFMHFAdapter`
  - `MoiraiHFAdapter`
  - `LagLlamaHFAdapter`

- 共通責務:
  - 内部ライブラリの DataFrame / Dataset 型を `TimeSeriesDataset` にマッピング
  - ハイパーパラメータを JSON 互換形式で受け渡し

### 2.4 Benchmark Adapter

- 役割:
  - BasicTS / TFB / gift-eval / Time-Series-Library のインタフェース差異を吸収
  - 「データセット × モデル × 設定」単位で評価ジョブを生成

### 2.5 Resource Profiler

```python
class ResourceProfiler:
    def __enter__(self): ...
    def __exit__(self, exc_type, exc, tb): ...
    def to_record(self) -> ResourceProfileRecord: ...
```

- `__enter__` でモニタリング開始
- `__exit__` でピーク値・平均値・累積時間を算出
- 結果は `ts_run_resource` テーブルに保存

## 3. エージェント設計

### 3.1 予測エージェント

```mermaid
flowchart TD
    U[ユーザ NL クエリ] --> P[Planner Agent]
    P --> DSel[データ選択サブエージェント]
    P --> MSel[モデル選択サブエージェント]
    P --> Cfg[評価・アンサンブル方針決定]

    DSel --> Pipe[Pipeline 実行]
    MSel --> Pipe
    Cfg --> Pipe

    Pipe --> R[結果メタデータ]
    R --> Expl[Explainer Agent]
    Expl --> U
```

- Planner Agent:
  - 目的の解釈（予測 / 異常検知 / 因果解析）
  - 必要な時系列・期間・集約粒度の決定
- Model Selection Agent:
  - データ特性（季節性、長系列か短系列か、マルチバリアントか）を診断
  - TSFM / 統計 / Deep モデルの組み合わせを提案
- Explainer Agent:
  - DB に保存されたメタデータを参照し、自然言語で説明を生成

### 3.2 異常検知エージェント

- Argos / anomaly-agent と連携し、
  - ルールベース + 統計的手法 + LLM ベースの検出結果を統合
  - 誤検知が多いルールのフィードバックループを設計

## 4. 代表的シーケンス設計

### 4.1 「テーブルから予測」シーケンス

```mermaid
sequenceDiagram
    participant U as User
    participant UI as API/UI
    participant L as LLM
    participant A as Agent Orchestrator
    participant P as Pipeline
    participant DB as Meta DB

    U->>UI: POST /forecast {table, horizon, query}
    UI->>L: NL プロンプト生成
    L-->>A: タスク計画(JSON)
    A->>P: パイプライン設定
    P->>P: 前処理・学習・予測・評価
    P->>DB: メタデータ保存
    P-->>A: 予測値＋run_id
    A-->>L: 要約用コンテキスト
    L-->>UI: 予測値＋説明テキスト
    UI-->>U: レスポンス返却
```

## 5. コンフィグレーション設計（例）

- `config/pipeline/default.yaml`

```yaml
data:
  max_rows: 1000000
  freq_infer: true

models:
  classical:
    - name: statsforecast_arima
      enabled: true
  deep:
    - name: neuralforecast_nbeats
      enabled: true
  tsfm:
    - name: chronos_t5_large
      enabled: true
    - name: timesfm_200m
      enabled: true

evaluation:
  metrics: [mape, smape, rmse, crps]
  backtest:
    n_folds: 5
    horizon: 30

resources:
  profile_interval_sec: 1.0
```

## 6. エラーハンドリング・ログ設計（概要）

- 例外種別:
  - DB 接続エラー
  - スキーマ推論失敗
  - モデル学習失敗（収束しない、メモリ不足 等）
  - TSFM API エラー
- ログ粒度:
  - audit ログ: 実験・実行者・実行結果
  - system ログ: エラー／警告
  - resource ログ: リソース計測結果（DB にも保存）

