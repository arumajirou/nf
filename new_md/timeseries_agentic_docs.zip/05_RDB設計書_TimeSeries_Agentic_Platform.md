# 05. RDB 設計書 — 自律的時系列予測研究プラットフォーム

## 1. 概要

本書は、`ts_meta` スキーマにおける RDB 設計（ER 図、正規化方針、インデックス設計の方針）を記載する。

## 2. ER 図（詳細）

```mermaid
erDiagram
    TS_DATASET {
        BIGSERIAL dataset_id PK
        VARCHAR name
        VARCHAR source_schema
        VARCHAR source_table
        VARCHAR time_column
        VARCHAR target_column
        JSONB   id_columns
        VARCHAR freq
    }

    TS_EXPERIMENT {
        BIGSERIAL experiment_id PK
        BIGINT dataset_id FK
        VARCHAR name
        TEXT description
        VARCHAR task_type
        JSONB config
        VARCHAR created_by
    }

    TS_MODEL {
        BIGSERIAL model_id PK
        VARCHAR framework
        VARCHAR model_type
        VARCHAR version
        JSONB hyperparams
        TEXT artifact_path
        BOOLEAN is_tsfm
        BOOLEAN created_by_agent
    }

    TS_RUN {
        BIGSERIAL run_id PK
        BIGINT experiment_id FK
        BIGINT model_id FK
        VARCHAR status
        INTEGER random_seed
        TIMESTAMPTZ started_at
        TIMESTAMPTZ ended_at
    }

    TS_RUN_RESOURCE {
        BIGSERIAL run_resource_id PK
        BIGINT run_id FK
        VARCHAR node_name
        NUMERIC cpu_usage_avg
        NUMERIC cpu_usage_max
        NUMERIC gpu_time_sec
        NUMERIC gpu_vram_max_gb
        NUMERIC ram_max_gb
        NUMERIC io_read_mb
        NUMERIC io_write_mb
    }

    TS_METRIC {
        BIGSERIAL metric_id PK
        BIGINT run_id FK
        VARCHAR dataset_role
        VARCHAR metric_name
        NUMERIC metric_value
        INTEGER horizon
        VARCHAR segment
    }

    TS_FORECAST {
        BIGSERIAL forecast_id PK
        BIGINT run_id FK
        JSONB series_key
        TIMESTAMPTZ timestamp
        INTEGER horizon
        DOUBLE y_hat
        DOUBLE y_hat_lower
        DOUBLE y_hat_upper
        BOOLEAN is_ensemble
    }

    TS_ENSEMBLE {
        BIGSERIAL ensemble_id PK
        BIGINT experiment_id FK
        VARCHAR strategy
        JSONB config
    }

    TS_ENSEMBLE_MEMBER {
        BIGSERIAL ensemble_member_id PK
        BIGINT ensemble_id FK
        BIGINT run_id FK
        NUMERIC weight
    }

    TS_CAUSAL_GRAPH {
        BIGSERIAL causal_graph_id PK
        BIGINT dataset_id FK
        VARCHAR method
        JSONB graph
    }

    TS_CAUSAL_EFFECT {
        BIGSERIAL causal_effect_id PK
        BIGINT causal_graph_id FK
        VARCHAR cause
        VARCHAR effect
        NUMERIC effect_size
        NUMERIC ci_low
        NUMERIC ci_high
    }

    TS_ANOMALY_EVENT {
        BIGSERIAL anomaly_event_id PK
        BIGINT run_id FK
        TIMESTAMPTZ start_time
        TIMESTAMPTZ end_time
        VARCHAR severity
        JSONB detail
    }

    TS_AGENT_SESSION {
        BIGSERIAL agent_session_id PK
        VARCHAR agent_type
        JSONB request
        TEXT response_summary
    }

    TS_AGENT_STEP {
        BIGSERIAL agent_step_id PK
        BIGINT agent_session_id FK
        INTEGER step_index
        VARCHAR tool_name
        JSONB tool_input
        JSONB tool_output
    }

    TS_DATASET ||--o{ TS_EXPERIMENT : has
    TS_EXPERIMENT ||--o{ TS_RUN : includes
    TS_MODEL ||--o{ TS_RUN : used_in
    TS_RUN ||--o{ TS_RUN_RESOURCE : profiled_by
    TS_RUN ||--o{ TS_METRIC : evaluated_by
    TS_RUN ||--o{ TS_FORECAST : produces
    TS_EXPERIMENT ||--o{ TS_ENSEMBLE : defines
    TS_ENSEMBLE ||--o{ TS_ENSEMBLE_MEMBER : contains
    TS_RUN ||--o{ TS_ENSEMBLE_MEMBER : component_of
    TS_DATASET ||--o{ TS_CAUSAL_GRAPH : has
    TS_CAUSAL_GRAPH ||--o{ TS_CAUSAL_EFFECT : yields
    TS_RUN ||--o{ TS_ANOMALY_EVENT : detects
    TS_AGENT_SESSION ||--o{ TS_AGENT_STEP : consists_of
```

## 3. 正規化方針

- 第 3 正規形を基本とし、以下を考慮する。
  - 実験設定・ハイパーパラメータ・系列キーなどは JSONB とし、  
    スキーマ変更を極力抑えて拡張性を確保。
  - 頻繁にクエリされるキー（dataset_id, experiment_id, model_id, run_id 等）は  
    明示的な列として持ち、インデックスを貼る。

## 4. インデックス設計方針（例）

- `ts_run (experiment_id, model_id, status)`
- `ts_metric (run_id, metric_name)`
- `ts_forecast (run_id, timestamp)`
- `ts_anomaly_event (start_time, end_time)`
- `ts_causal_effect (cause, effect)`

## 5. 物理設計上の留意事項

- 予測結果テーブルはレコード数が膨大になり得るため、
  - 実験完了後に Parquet 等へのエクスポート＋アーカイブを行い、
  - RDB 上には最新実験や集約結果を中心に保持する運用ポリシーを設ける。
- 将来的なスケーリングとして、時系列データそのものは  
  別ストレージ（Data Lake, 時系列 DB）に置き、`ts_meta` はメタデータに特化させることを推奨する。
