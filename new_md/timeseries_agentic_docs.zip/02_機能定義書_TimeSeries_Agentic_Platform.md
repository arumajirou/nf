# 02. 機能定義書 — 自律的時系列予測研究プラットフォーム

## 1. 文書情報

- 文書名: 自律的時系列予測研究プラットフォーム 機能定義書
- 版数  : 0.1（ドラフト）

## 2. システム全体機能一覧

### 2.1 機能一覧テーブル

| ID | 機能カテゴリ | 機能名 | 概要 | 優先度 |
|----|--------------|--------|------|--------|
| F-01 | データ取得 | DB テーブル取得機能 | PostgreSQL から指定テーブルを取得し、時系列として解釈可能な形にロードする | ★★★★☆ |
| F-02 | スキーマ推論 | 時系列スキーマ自動推論 | 日付/時間列やターゲット列、ID 列を自動推定し、ユーザに提示・修正可能にする | ★★★★☆ |
| F-03 | 前処理 | 欠損補完・外れ値処理 | PyPOTS / tsfel / tsflex などを用いた前処理・特徴量生成 | ★★★★☆ |
| F-04 | モデル選択 | 自動モデル候補生成 | LLM/ルールベースで Chronos / TimesFM / Merlion / Darts 等の候補を自動列挙 | ★★★★☆ |
| F-05 | モデル学習 | 個別モデル学習・保存 | 各ライブラリのモデルを統一インタフェースで学習・モデルファイルとして保存 | ★★★★★ |
| F-06 | 予測 | 予測値生成 | 未来区間に対するポイント予測・区間予測の生成 | ★★★★★ |
| F-07 | アンサンブル | アンサンブル予測生成 | 単体モデルを重み付き・スタッキング等でアンサンブル | ★★★★☆ |
| F-08 | 評価 | 統一評価・ベンチマーク | BasicTS / TFB / gift-eval 等を用いた公平ベンチマーク | ★★★★★ |
| F-09 | 異常検知 | 異常検知パイプライン | Merlion / Argos / anomaly-agent を利用した異常検知 | ★★★★☆ |
| F-10 | 因果推論 | 因果解析パイプライン | causal-learn などを用いた因果グラフ推定・効果推定 | ★★★☆☆ |
| F-11 | リソース計測 | 学習・推論リソースログ | CPU/GPU/IO/RAM/VRAM/時間等のメトリクス計測 | ★★★★★ |
| F-12 | メタデータ管理 | 実験・モデル・結果メタ情報管理 | RDB 上で一元管理するための CRUD API | ★★★★★ |
| F-13 | エージェント UI | 自然言語インタフェース | LLM チャットからのクエリ受付とワークフロー実行 | ★★★★☆ |
| F-14 | 可視化 | ダッシュボード | モデル性能・リソース・異常検知結果の可視化 | ★★★☆☆ |

## 3. 機能定義詳細

### F-01: DB テーブル取得機能

- 入力:
  - DB 接続情報（環境変数・設定ファイル）
  - テーブル識別子（schema.table）
- 処理:
  - psycopg2 / SQLAlchemy による SELECT
  - タイムスタンプ列候補の検出（型・名前パターン）
- 出力:
  - pandas.DataFrame または Polars DataFrame
  - メタ情報（列名・型・NULL 率 等）

### F-02: 時系列スキーマ自動推論

```mermaid
flowchart LR
    DF[入力 DataFrame] --> DETECT[列型・名前解析]
    DETECT --> CAND[候補列集合
(time, target, id)]
    CAND --> LLM[LLM による補助判定
(オプション)]
    LLM --> CONFIRM[ユーザ確認]
    CONFIRM --> SCHEMA[確定スキーマ定義]
```

- 機能要件:
  - タイムスタンプ列の自動候補提示
  - 複数系列（id 列）の自動検出
  - ターゲット列・説明変数の区別

### F-04/F-05/F-06: モデル選択・学習・予測

- モデルカテゴリ:
  - 統計モデル: ARIMA, ETS, Prophet, statsforecast 系
  - 伝統 ML: RandomForest, XGBoost, CatBoost 等（mlforecast など）
  - Deep TS: N-BEATS, TCN, TFT, PatchTST, DLinear, TimesNet 等（neuralforecast, Darts, GluonTS）
  - TSFM: Chronos, TimesFM, Moirai, Granite, Falcon-TST, MOMENT-1, Lag-Llama 等

- 共通インタフェース（例）:

```python
class BaseTimeSeriesModel(Protocol):
    def fit(self, data: TimeSeriesDataset, **kwargs) -> "BaseTimeSeriesModel": ...
    def predict(self, horizon: int, **kwargs) -> ForecastResult: ...
    def save(self, path: str) -> None: ...
    @classmethod
    def load(cls, path: str) -> "BaseTimeSeriesModel": ...
```

### F-07: アンサンブル機能

- 機能:
  - Simple average, weighted average, stacking, MLP, gradient boosting 等
  - LLM によるメタ学習方針の提案（「長期予測には TSFM を重めに」など）

### F-08: ベンチマーク機能

- 機能:
  - BasicTS / TFB / gift-eval が提供する評価プロトコルへのアダプタ
  - データセット・モデル・評価設定を統一フォーマットに変換
  - 評価結果を DB に格納し、リーダーボードビューを提供

### F-09: 異常検知

- パイプライン例:
  - Merlion: 統計 + ML + DL を統合した異常検知フレームワーク
  - Argos: LLM エージェントによるルール生成＋評価
  - anomaly-agent: LangGraph による 2 ノード（検出・検証）構成

### F-11: リソース計測

- 測定指標:
  - CPU 使用率 / 累積 CPU 時間
  - GPU 稼働時間 / 最大 VRAM 使用量
  - RAM 最大使用量
  - IO (Read/Write MB)
  - 1 秒あたりサンプル数・ステップ数 等

- 計測方法:
  - psutil によるプロセス監視
  - nvidia-smi もしくは NVML ライブラリによる GPU モニタリング
  - モデル実行コンテキストごとに計測セッションを張る

### F-12: メタデータ管理

- 主なエンティティ:
  - データセット
  - 実験
  - モデル
  - ラン（Run）
  - 評価指標
  - 予測結果
  - アンサンブル
  - 異常事象
  - 因果グラフ / 効果推定

詳細なテーブル定義は「04_DBテーブル定義書」を参照。

### F-13: エージェント UI

```mermaid
sequenceDiagram
    participant User as 利用者
    participant UI as チャット UI
    participant LLM as LLM
    participant Orchestrator as TS エージェント
    participant Tools as TS ツール群

    User->>UI: 「来月の売上は？<table=sales_daily>」
    UI->>LLM: プロンプト送信
    LLM->>Orchestrator: 計画（データ取得→モデル選択→予測）
    Orchestrator->>Tools: DB 接続・パイプライン実行
    Tools-->>Orchestrator: 予測値＋メタ情報
    Orchestrator-->>LLM: 結果サマリ
    LLM-->>User: 予測＋根拠説明を自然言語で返答
```

## 4. 非機能要件の機能への割当（抜粋）

| 非機能要件 | 関連機能 ID | 概要 |
|------------|-------------|------|
| 拡張性 | F-04, F-05, F-07, F-08 | モデルプラグインアーキテクチャで新規 TSFM を追加可能 |
| 再現性 | F-01〜F-12 | 実験構成と結果を DB に完全保存 |
| 可観測性 | F-11, F-14 | リソース計測とダッシュボード |
| 自律性 | F-04, F-07, F-08, F-13 | LLM エージェントによる自動モデル選択・評価 |
