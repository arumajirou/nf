# 04. DB テーブル定義書 — 自律的時系列予測研究プラットフォーム

## 1. 概要

本書は、時系列実験・モデル・結果・リソース情報を一元管理するための  
PostgreSQL スキーマ定義を示す。

想定スキーマ名: `ts_meta`

## 2. 主なテーブル一覧

| テーブル論理名 | 物理名 | 概要 |
|----------------|--------|------|
| データセット | ts_dataset | 入力データセット（DB テーブル）の情報 |
| 時系列系列メタ | ts_series | 個々の系列（id）のメタ情報 |
| 実験 | ts_experiment | 実験（Experiment）単位の管理 |
| モデル | ts_model | モデル定義（ライブラリ種別、ハイパラ等） |
| ラン | ts_run | 実験 × モデル × データセットの実行単位 |
| ランリソース | ts_run_resource | ランごとのリソース計測結果 |
| 評価指標 | ts_metric | ランごとの評価メトリクス |
| 予測結果 | ts_forecast | 予測値・予測区間 |
| アンサンブル | ts_ensemble | アンサンブルモデル定義 |
| アンサンブル構成 | ts_ensemble_member | アンサンブル構成要素 |
| 因果グラフ | ts_causal_graph | 因果グラフ表現 |
| 因果効果 | ts_causal_effect | 効果推定結果 |
| 異常イベント | ts_anomaly_event | 異常検知結果 |
| エージェントセッション | ts_agent_session | LLM エージェントのセッション情報 |
| エージェントステップ | ts_agent_step | セッション内ステップ |

## 3. テーブル定義詳細

### 3.1 データセット: `ts_dataset`

| No | 論理名 | 物理名 | 型 | PK | Not Null | 説明 |
|----|--------|--------|----|----|---------|------|
| 1 | データセットID | dataset_id | BIGSERIAL | ◯ | ◯ | 主キー |
| 2 | 名前 | name | VARCHAR(255) |  | ◯ | 論理名 |
| 3 | 説明 | description | TEXT |  |  | 概要説明 |
| 4 | ソーススキーマ | source_schema | VARCHAR(255) |  | ◯ | 業務 DB スキーマ名 |
| 5 | ソーステーブル | source_table | VARCHAR(255) |  | ◯ | 業務 DB テーブル名 |
| 6 | 時刻列名 | time_column | VARCHAR(255) |  | ◯ | タイムスタンプ列 |
| 7 | ターゲット列名 | target_column | VARCHAR(255) |  | ◯ | 目的変数列 |
| 8 | ID 列名リスト | id_columns | JSONB |  |  | 複数 ID の場合 |
| 9 | 周期 | freq | VARCHAR(32) |  |  | 日次/週次/分など |
|10 | 作成日時 | created_at | TIMESTAMPTZ |  | ◯ | レコード作成日時 |
|11 | 更新日時 | updated_at | TIMESTAMPTZ |  | ◯ | レコード更新日時 |

### 3.2 実験: `ts_experiment`

| No | 論理名 | 物理名 | 型 | PK | Not Null | 説明 |
|----|--------|--------|----|----|---------|------|
| 1 | 実験ID | experiment_id | BIGSERIAL | ◯ | ◯ | 主キー |
| 2 | データセットID | dataset_id | BIGINT |  | ◯ | ts_dataset への FK |
| 3 | 名前 | name | VARCHAR(255) |  | ◯ | 実験名 |
| 4 | 説明 | description | TEXT |  |  | 実験の目的等 |
| 5 | タスク種別 | task_type | VARCHAR(64) |  | ◯ | forecast/anomaly/causal 等 |
| 6 | 設定 | config | JSONB |  |  | YAML/JSON の展開 |
| 7 | 作成者 | created_by | VARCHAR(255) |  |  | 実験実行者 |
| 8 | 作成日時 | created_at | TIMESTAMPTZ |  | ◯ | 作成日時 |

### 3.3 モデル: `ts_model`

| No | 論理名 | 物理名 | 型 | PK | Not Null | 説明 |
|----|--------|--------|----|----|---------|------|
| 1 | モデルID | model_id | BIGSERIAL | ◯ | ◯ | 主キー |
| 2 | フレームワーク | framework | VARCHAR(128) |  | ◯ | darts/sktime/neuralforecast 等 |
| 3 | モデル種別 | model_type | VARCHAR(128) |  | ◯ | NBEATS/ARIMA/ChronosT5 等 |
| 4 | バージョン | version | VARCHAR(64) |  |  | ライブラリ/モデルバージョン |
| 5 | ハイパラ | hyperparams | JSONB |  |  | モデルハイパーパラメータ |
| 6 | モデルパス | artifact_path | TEXT |  |  | モデルファイルの保存先 |
| 7 | TSFM フラグ | is_tsfm | BOOLEAN |  | ◯ | TSFM かどうか |
| 8 | エージェント生成フラグ | created_by_agent | BOOLEAN |  | ◯ | LLM エージェントが自動生成したか |
| 9 | 作成日時 | created_at | TIMESTAMPTZ |  | ◯ | 作成日時 |

### 3.4 ラン: `ts_run`

| No | 論理名 | 物理名 | 型 | PK | Not Null | 説明 |
|----|--------|--------|----|----|---------|------|
| 1 | ランID | run_id | BIGSERIAL | ◯ | ◯ | 主キー |
| 2 | 実験ID | experiment_id | BIGINT |  | ◯ | ts_experiment への FK |
| 3 | モデルID | model_id | BIGINT |  | ◯ | ts_model への FK |
| 4 | ステータス | status | VARCHAR(32) |  | ◯ | pending/running/success/failed |
| 5 | シード値 | random_seed | INTEGER |  |  | 乱数シード |
| 6 | 開始時刻 | started_at | TIMESTAMPTZ |  |  | 実行開始 |
| 7 | 終了時刻 | ended_at | TIMESTAMPTZ |  |  | 実行終了 |
| 8 | 備考 | remark | TEXT |  |  | 例外メッセージ等 |

### 3.5 ランリソース: `ts_run_resource`

| No | 論理名 | 物理名 | 型 | PK | Not Null | 説明 |
|----|--------|--------|----|----|---------|------|
| 1 | ランリソースID | run_resource_id | BIGSERIAL | ◯ | ◯ | 主キー |
| 2 | ランID | run_id | BIGINT |  | ◯ | ts_run への FK |
| 3 | ノード名 | node_name | VARCHAR(255) |  |  | 実行ノード ID |
| 4 | CPU 平均使用率 | cpu_usage_avg | NUMERIC(5,2) |  |  | % |
| 5 | CPU 最大使用率 | cpu_usage_max | NUMERIC(5,2) |  |  | % |
| 6 | GPU 稼働時間 | gpu_time_sec | NUMERIC(12,2) |  |  | 秒 |
| 7 | GPU 最大 VRAM | gpu_vram_max_gb | NUMERIC(8,2) |  |  | GB |
| 8 | RAM 最大使用量 | ram_max_gb | NUMERIC(8,2) |  |  | GB |
| 9 | IO 読み取り | io_read_mb | NUMERIC(12,2) |  |  | MB |
|10 | IO 書き込み | io_write_mb | NUMERIC(12,2) |  |  | MB |
|11 | 実測学習時間 | train_time_sec | NUMERIC(12,2) |  |  | 秒 |
|12 | 実測推論時間 | infer_time_sec | NUMERIC(12,2) |  |  | 秒 |

### 3.6 評価指標: `ts_metric`

| No | 論理名 | 物理名 | 型 | PK | Not Null | 説明 |
|----|--------|--------|----|----|---------|------|
| 1 | メトリクスID | metric_id | BIGSERIAL | ◯ | ◯ | 主キー |
| 2 | ランID | run_id | BIGINT |  | ◯ | ts_run への FK |
| 3 | データ役割 | dataset_role | VARCHAR(32) |  | ◯ | train/val/test/backtest 等 |
| 4 | 指標名 | metric_name | VARCHAR(64) |  | ◯ | mape/rmse/crps 等 |
| 5 | 値 | metric_value | NUMERIC(20,8) |  | ◯ | 指標値 |
| 6 | ホライゾン | horizon | INTEGER |  |  | 予測ステップ |
| 7 | セグメント | segment | VARCHAR(255) |  |  | シリーズ ID 等 |

### 3.7 予測結果: `ts_forecast`

| No | 論理名 | 物理名 | 型 | PK | Not Null | 説明 |
|----|--------|--------|----|----|---------|------|
| 1 | 予測ID | forecast_id | BIGSERIAL | ◯ | ◯ | 主キー |
| 2 | ランID | run_id | BIGINT |  | ◯ | ts_run への FK |
| 3 | シリーズキー | series_key | JSONB |  | ◯ | ID 列の組 |
| 4 | 予測時刻 | timestamp | TIMESTAMPTZ |  | ◯ | 予測対象の時間 |
| 5 | ホライゾン | horizon | INTEGER |  | ◯ | ステップ数 |
| 6 | 予測値 | y_hat | DOUBLE PRECISION |  | ◯ | 予測値 |
| 7 | 下限 | y_hat_lower | DOUBLE PRECISION |  |  | 予測区間下限 |
| 8 | 上限 | y_hat_upper | DOUBLE PRECISION |  |  | 予測区間上限 |
| 9 | アンサンブルフラグ | is_ensemble | BOOLEAN |  | ◯ | アンサンブルかどうか |

### 3.8 ER 図（概要）

```mermaid
erDiagram
    TS_DATASET ||--o{ TS_EXPERIMENT : has
    TS_EXPERIMENT ||--o{ TS_RUN : includes
    TS_MODEL ||--o{ TS_RUN : used_in
    TS_RUN ||--o{ TS_RUN_RESOURCE : profiled_by
    TS_RUN ||--o{ TS_METRIC : evaluated_by
    TS_RUN ||--o{ TS_FORECAST : produces
    TS_ENSEMBLE ||--o{ TS_ENSEMBLE_MEMBER : consists_of
    TS_RUN ||--o{ TS_ENSEMBLE_MEMBER : source_run
    TS_CAUSAL_GRAPH ||--o{ TS_CAUSAL_EFFECT : produces
    TS_RUN ||--o{ TS_ANOMALY_EVENT : detects
    TS_AGENT_SESSION ||--o{ TS_AGENT_STEP : contains
```

他テーブル（`ts_causal_graph`, `ts_causal_effect`, `ts_anomaly_event`, `ts_agent_session`, `ts_agent_step`）についても同様の形式で定義する。
