# 自律的時系列予測研究プラットフォーム ドキュメント一式

本 ZIP には、PostgreSQL 上のテーブルを入力として、  
各種時系列ライブラリおよび Time Series Foundation Model / エージェント型フレームワークを統合した  
**自律的時系列予測・異常検知・因果解析プラットフォーム**の設計ドキュメントを含みます。

## 含まれるドキュメント

1. `01_詳細提案書_TimeSeries_Agentic_Platform.md`  
2. `02_機能定義書_TimeSeries_Agentic_Platform.md`  
3. `03_詳細機能設計仕様書_TimeSeries_Agentic_Platform.md`  
4. `04_DBテーブル定義書_TimeSeries_Agentic_Platform.md`  
5. `05_RDB設計書_TimeSeries_Agentic_Platform.md`  

## 対象となる主なライブラリ / モデル群（抜粋）

- AutoGluon / AutoGluon TimeSeries, Chronos-Bolt 系
- sktime, unit8co/darts, GluonTS, Merlion, PyPOTS, tsflex, seglearn などの伝統/Deep TS ライブラリ
- Nixtla スタック: statsforecast / neuralforecast / mlforecast / hierarchicalforecast / utilsforecast / coreforecast
- Matrix Profile 系: matrixprofile, matrixprofile-ts
- 特徴抽出: tsfel, temporian, tsflex
- Foundation Models / TSFM:
  - amazon/chronos-2, amazon/chronos-t5-large
  - google/timesfm 系
  - ibm-granite/granite-timeseries-ttm-r2
  - ant-intl/Falcon-TST_Large
  - AutonLab/MOMENT-1-large
  - time-series-foundation-models/Lag-Llama
  - Salesforce/moirai-1.1-R-large
- ベンチマーク / 評価:
  - GestaltCogTeam/BasicTS
  - decisionintelligence/TFB
  - SalesforceAIResearch/gift-eval
  - thuml/Large-Time-Series-Model, thuml/Time-Series-Library
- エージェント / LLM 連携:
  - Y-Research-SBU/TimeSeriesScientist
  - AzulGarza/timecopilot
  - microsoft/argos
  - andrewm4894/anomaly-agent

## 想定 DB 設定（開発環境）

```text
host     : localhost
port     : 5432
database : postgres
user     : postgres
password : z
```

本ドキュメントは業務システムレベルを意識した書式で記載していますが、  
実装言語・フレームワークやインフラ構成はプロジェクトの制約に応じて調整可能です。
