# ATSRE-Spark / TSFM 統合環境 実装計画書

## 1. 文書情報

- 文書名: ATSRE-Spark / TSFM 統合環境 実装計画書（実装ロードマップ・WBS）
- 版数  : 0.1（ドラフト）
- 作成日: 2025-11-17
- 対象環境: 
  - PostgreSQL（メタデータスキーマ: `atsre_meta`）
  - Apache Spark 3.x クラスタ（Kubernetes / Standalone / YARN いずれか）
  - 既存ワークスペース:
    - timeseries_agentic_docs
    - ts_benchmark_design_docs_v2
    - atsre_spark_docs
    - nf_loto_workspace_ws4_tsfm_ai_scientist_augmented_v4

---

## 2. 前提・統合対象システムの整理

### 2.1 既存 zip / ディレクトリと役割

| 識別子 | 内容 | 本計画における位置づけ |
|--------|------|------------------------|
| timeseries_agentic_docs | 既存の自律的時系列研究環境（DB メタ設計、機能仕様など）の初期版設計 | ATSRE-Spark 設計の源流。DB メタスキーマ・モデル/ラン/メトリクス構造のベースとして採用 |
| ts_benchmark_design_docs_v2 | 時系列ベンチマーク設計資料（TS ライブラリ比較・評価指標・ベンチ用データセット定義など） | ATSRE における Benchmark Service / リーダーボード機能の設計根拠 |
| atsre_spark_docs | Apache Spark を前提に再設計した ATSRE-Spark の詳細提案書・機能定義・詳細設計・DB 設計 | 本計画で実装する「ターゲットアーキテクチャ」の公式仕様として扱う |
| nf_loto_workspace_ws4_tsfm_ai_scientist_augmented_v4 | TSFM / AI Scientist 系のコード・ノートブック・ユーティリティ群を含む既存ワークスペース | 実装時に流用するコード資産。TSFM 実験基盤・エージェント実装の雛形として統合 |

※ 実際のディレクトリパス（本環境）:

```text
/mnt/data/atsre_unified_workspace
- timeseries_agentic_docs: /mnt/data/atsre_unified_workspace/timeseries_agentic_docs
- ts_benchmark_design_docs_v2: /mnt/data/atsre_unified_workspace/ts_benchmark_design_docs_v2
- atsre_spark_docs: /mnt/data/atsre_unified_workspace/atsre_spark_docs
- nf_loto_workspace_ws4_tsfm_ai_scientist_augmented_v4: /mnt/data/atsre_unified_workspace/nf_loto_workspace_ws4_tsfm_ai_scientist_augmented_v4
```

### 2.2 統合後に目指すシステム像（要約）

1. PostgreSQL (`atsre_meta`) をメタデータの単一ソース・オブ・トゥルースとする。  
2. Apache Spark が **データロード・前処理・特徴量生成・大規模バックテスト** の実行基盤となる。  
3. AutoGluon / Darts / Nixtla / sktime / Merlion / GluonTS / PyTorch-TS / AutoTS / TSFM 群を  
   **プラグイン型モデルアダプタ** として統合する。  
4. TimeSeriesScientist / TimeCopilot / Argos / anomaly-agent などの LLM エージェントを、  
   **Orchestrator / Planner / Forecaster / Causal / Reporter** などの役割を持つサブエージェントとして構成する。  
5. BasicTS / TFB / gift-eval / Time-Series-Library / Large-Time-Series-Model を利用した  
   **公平なベンチマーク / リーダーボード機能** を提供する。  
6. CPU/GPU/IO/RAM/VRAM/時間などの実行コストを全て `atsre_meta` に記録し、  
   モデル選択・アンサンブル・運用判断の根拠として活用する。  

---

## 3. 実装フェーズとマイルストーン

### 3.1 フェーズ構成（概要）

| フェーズ | 期間の目安 | 主なゴール |
|----------|------------|------------|
| Phase 0  | 1〜2 週間  | 環境構築・既存ワークスペース統合・PoC 確認 |
| Phase 1  | 3〜4 週間  | メタデータ DB 実装・Spark ベース ETL/Feature パイプライン実装 |
| Phase 2  | 4〜6 週間  | モデルアダプタ群（AutoGluon / Darts / Nixtla / TSFM など）の実装 |
| Phase 3  | 4〜6 週間  | エージェント層（TimeSeriesScientist / TimeCopilot / Argos / anomaly-agent）統合 |
| Phase 4  | 3〜4 週間  | ベンチマークスイート・リーダーボード・運用ダッシュボード整備 |
| Phase 5  | 継続       | チューニング・運用ルール整備・高度化（ストリーミング・RAG など） |

---

## 4. フェーズ別 実装タスク詳細（WBS）

### Phase 0: 環境構築・既存ワークスペース統合

#### 4.0.1 インフラ / 基盤準備

- [ ] Git リポジトリ統合
  - `timeseries_agentic_docs` / `atsre_spark_docs` 内の設計書を `/docs/` 配下に整理。
  - `nf_loto_workspace_ws4_tsfm_ai_scientist_augmented_v4` のコードを `/workspace/` 配下にインポート。
- [ ] Python 環境定義
  - `pyproject.toml` または `poetry.lock` / `requirements.txt` を整理し、
    - Spark, PostgreSQL, AutoGluon, Darts, Nixtla, sktime, Merlion, TSFM, LangChain/LangGraph, causal-learn などの依存関係を明示化。
- [ ] Spark クラスタ準備
  - ローカル or 単一ノード版で PoC を行うため、`spark-standalone` または `spark-on-k8s` の最小構成を用意。

#### 4.0.2 既存コード・設計の読み込み・マッピング

- [ ] `timeseries_agentic_docs` / `atsre_spark_docs` に含まれる ER 図・API 設計と、  
      `nf_loto_workspace` 内の実装を比較し、以下をマッピング:
  - 既存の TSFM 実験スクリプト → ATSRE-Spark における ModelAdapter 実装候補
  - 既存の AI Scientist / Agent 的なコード → Orchestrator / Planner / Reporter の実装候補
- [ ] ギャップ一覧を作成（必要だが現状存在しない機能）
  - 例: `ts_run` / `ts_metric` / `ts_forecast` に書き込む実装、Spark 経由の JDBC ロードなど。

### Phase 1: メタデータ DB & Spark ETL / Feature パイプライン実装

#### 4.1.1 メタデータ DB（atsre_meta）の構築

- [ ] PostgreSQL に `atsre_meta` スキーマを作成。
- [ ] `atsre_spark_docs` / `timeseries_agentic_docs` の DB 定義書に沿って、DDL を実行。
  - `ts_dataset`, `ts_experiment`, `ts_model`, `ts_run`, `ts_run_resource`, `ts_metric`, `ts_forecast` など。
- [ ] 初期データ投入
  - サンプルデータセット定義（デモ用）を `ts_dataset` に登録。
  - モデルカタログの初期行（AutoGluon, Darts, Nixtla, TSFM 各 1〜2 種）を `ts_model` に登録。

#### 4.1.2 Spark ベースのデータ取得 / プロファイル機能

- [ ] `PostgresTimeSeriesLoader`（Spark 版）の実装
  - JDBC URL / schema.table / time_column / id_columns を受け取って Spark DataFrame を返す。
- [ ] DataProfile ジョブ（J-01）の実装
  - 行数・期間・欠損率・基礎統計情報を計算し、`ts_dataset` または専用テーブルに保存。

#### 4.1.3 特徴量生成パイプライン

- [ ] FeatureGen ジョブ（J-02）の実装
  - ローリング統計・ラグ特徴・カレンダー特徴を Spark 上で生成。
- [ ] tsfel / temporian / tsflex 連携
  - 必要に応じて Spark → pandas 変換で局所的に実行し、結果を再度 Spark に戻すパターンを整理。

### Phase 2: モデルアダプタ群の実装

#### 4.2.1 共通インタフェース層

- [ ] `BaseTSModelAdapter` 抽象クラス/Protocol を実装（fit / predict / save / load）。
- [ ] フレームワーク種別（autogluon / darts / nixtla / sktime / merlion / tsfm）の列挙型を定義。

#### 4.2.2 フレームワーク別アダプタ実装

- [ ] Nixtla 系: `NixtlaNeuralForecastAdapter`, `NixtlaStatsForecastAdapter`, `NixtlaMLForecastAdapter`
- [ ] Darts: `DartsAdapter`（N-BEATS, TFT, TCN, DLinear 等を統合）
- [ ] sktime: 伝統的 ML / 時系列分類・異常検知をラップ
- [ ] GluonTS / PyTorch-TS / AutoTS: 既存ワークスペースコードを元にラッパーを実装
- [ ] TSFM 系: `ChronosAdapter`, `TimesFMAdapter`, `MoiraiAdapter`, `LagLlamaAdapter`, `GraniteAdapter` など
- [ ] Merlion / neural_prophet / UniTS / Time-LLM / Time-MoE のアダプタ（優先度高いものから）

#### 4.2.3 Spark との連携パターンの具体化

- [ ] Driver 学習パターン（小〜中規模）
  - Spark DataFrame → pandas に変換し、単一プロセスで学習。
- [ ] Executor UDF 学習パターン（多数系列）
  - Spark の groupBy(id).applyInPandas を使い、系列ごとに独立学習。
- [ ] `ts_run` / `ts_model` と連携するヘルパー実装
  - 学習開始時に run レコード作成、終了後にステータス更新＋モデルパス保存。

### Phase 3: エージェント層（LLM / TimeSeriesScientist / TimeCopilot / Argos / anomaly-agent）の統合

#### 4.3.1 Orchestrator / Planner / Forecaster / Reporter の実装

- [ ] LangGraph もしくは類似フレームワークで Orchestrator の DAG を定義。
- [ ] Planner Agent
  - DataProfile / ベンチマーク結果 / メタデータを参照し、候補モデルを選択。
- [ ] Forecaster Agent
  - Planner の計画に従って Spark ジョブ（Train / Forecast）を発行。
- [ ] Reporter Agent
  - `ts_metric`, `ts_run_resource`, `ts_forecast` を参照し、自然言語レポートを生成。

#### 4.3.2 TimeSeriesScientist / TimeCopilot とのブリッジ

- [ ] 既存の TimeSeriesScientist / TimeCopilot リポジトリ or コードを参照し、
  - 自動前処理・モデル選択・レポート生成部分をエージェントの一部として再利用。
- [ ] ATSRE-Spark 側のメタデータ構造に合わせたアダプタ層を実装。

#### 4.3.3 Argos / anomaly-agent 統合

- [ ] 異常検知ルール自動生成パイプラインを設計
  - 時間窓・閾値・ルールセットを JSON で管理し、`ts_anomaly_event` に結果を書き込む。

### Phase 4: ベンチマーク・リーダーボード・ダッシュボード

#### 4.4.1 ベンチマークスイートの実装

- [ ] `ts_benchmark_suite` / `ts_benchmark_case` テーブルを追加。
- [ ] BasicTS / TFB / gift-eval / Time-Series-Library / Large-Time-Series-Model を Spark ジョブ J-05 として実装。

#### 4.4.2 リーダーボード・可視化

- [ ] メトリクス・コストを横断的に可視化する SQL View を定義。
- [ ] Grafana / Metabase / Superset 等でダッシュボードを構築。

### Phase 5: 継続的高度化

- Spark Structured Streaming によるリアルタイム異常検知
- RAG（レポート・設計書のベクトル検索）と LLM の組み合わせ
- モデルライフサイクル管理（ロールアウト・ロールバック・シャドー運用）

---

## 5. 実装上の横断テーマ

### 5.1 テスト戦略

- 単体テスト
  - ModelAdapter ごとの I/O 仕様テスト（fit/predict の最小ケース）。
- 統合テスト
  - 「ts_dataset → Spark → Train → Forecast → ts_metric/ts_forecast」一連のフローを検証。
- ベンチマーク再現テスト
  - 既存 ts_benchmark_docs に記載されたスコアと一定範囲内で一致するか。

### 5.2 ロギング・トレース

- Spark ログ + アプリケーションログを統合し、run_id / spark_app_id をキーに追跡可能にする。
- 重要なエージェントステップは `ts_agent_session` / `ts_agent_step` に保存。

### 5.3 セキュリティ / 権限

- Spark から PostgreSQL への接続ユーザは、`atsre_meta` に対して INSERT/UPDATE/SELECT のみに限定。
- 業務スキーマに対しては SELECT のみを許可。

---

## 6. 成果物一覧

- 設計系
  - 既存設計書の統合版（/docs 以下に整理済み）
  - 本実装計画書（本ファイル）
- 実装系
  - Spark ジョブ群（DataProfile, FeatureGen, Train, Forecast, Benchmark, Anomaly, Causal）
  - ModelAdapter 実装群
  - LLM エージェント DAG 実装
- DB
  - `atsre_meta` スキーマおよび関連ビュー
  - ベンチマークスイート・リーダーボードビュー

---

## 7. 次アクション

1. Phase 0 の Git リポジトリ構成と Python 依存関係の確定。  
2. PostgreSQL に `atsre_meta` を作成し、DDL を流してスキーマを確定。  
3. Spark ローカルクラスタ上で、DataProfile ジョブ（J-01）の PoC を実行し、  
   メタ DB (`ts_dataset`) にプロファイル情報を書き込むところまで到達させる。  

この 3 ステップが完了すれば、ATSRE-Spark 全体の「背骨」が出来上がり、  
以降のモデル・エージェント・ベンチマーク統合を段階的に積み上げていける状態になる。
