# 詳細機能設計仕様書: ベンチマーク & LTSM 統合

## 1. パッケージ構成詳細

- nf_loto_platform/bench/
  - __init__.py
  - domain.py
  - adapters/
    - base.py
    - basicts_adapter.py
    - tfb_adapter.py
    - darts_adapter.py
    - sktime_adapter.py
    - neuralforecast_adapter.py
    - kats_adapter.py
    - gifteval_adapter.py
    - ltsm_adapter.py
  - repository.py
  - runner.py
  - cli.py
  - api.py (任意)

---

## 2. domain.py 詳細

- BenchmarkScenarioSpec
  - id: int | None
  - name: str
  - description: str
  - dataset_id: str
  - task_type: str
  - horizon: int | None
  - metrics: list[str]
  - framework_models: list[FrameworkModelSpec]
  - created_at: datetime
  - updated_at: datetime
- FrameworkModelSpec
  - framework: str
  - model_id: str
  - enabled: bool
  - params: dict[str, Any]
- BenchmarkRunSpec
  - scenario_id: int
  - run_mode: quick / full
  - seed: int
  - max_runtime_minutes: float | None
  - notes: str
- BenchmarkRunResult
  - run_id: int | None
  - scenario_id: int
  - framework: str
  - model_id: str
  - status: success / failed / skipped
  - metrics: dict[str, float]
  - started_at: datetime
  - finished_at: datetime
  - error_message: str | None
  - extra: dict[str, Any]

---

## 3. adapters/base.py 詳細

- BaseFrameworkAdapter
  - name: str
  - is_available() -> bool
  - supported_tasks() -> set[str]
  - run(scenario, models, run_spec) -> list[BenchmarkRunResult]

- 実装上の注意:
  - is_available では ImportError をキャッチして False を返す。
  - run 内では例外をキャッチし、individual result に status=failed を設定。

---

## 4. 各アダプタ設計方針

4.1 BasicTSAdapter
- BasicTS の設定ファイルテンプレートをベースに、
  scenario の条件を埋め込んで実行。
- 分散トレーニング設定は run_mode に応じて切り替え。

4.2 TFBAdapter
- TFB 提供のベンチマークスクリプトをラップ。
- ロト時系列に近いタスク設定を選択する。

4.3 DartsAdapter
- Darts のモデルクラス（NBEATSModel, TFTModel 等）を
  FrameworkModelSpec.model_id から動的に取得。
- 共通のトレイン/テスト分割ロジックを使用。

4.4 SktimeAdapter
- sktime の forecaster をラップし、古典系モデルをベンチマーク。

4.5 NeuralForecastAdapter
- 既存の AutoModelSpec / model_runner を呼び出し、
  nf_model_runs の結果を BenchmarkRunResult に写像。

4.6 KatsAdapter
- 異常検知用モデルを実行し、
  precision / recall / F1 相当の metrics を計算。

4.7 GiftEvalAdapter
- gift-eval に対して対象モデル情報とデータを渡し、
  出力 JSON からメトリクスを抽出。

4.8 LTSMAdapter
- Large-Time-Series-Model 内のモデルをロード。
- nf_loto の panel を LTSM 用フォーマットに変換して学習/推論。

---

## 5. runner.py 詳細

- BenchmarkRunner
  - __init__(adapters: dict[str, BaseFrameworkAdapter], repo: BenchmarkRepository)
  - run_scenario(run_spec: BenchmarkRunSpec) -> int

- 処理フロー:
  1. repository から scenario を取得。
  2. run レコードを作成（status=pending → running）。
  3. 各フレームワークについて:
     - models を抽出
     - is_available を確認
     - run を実行、結果を save_results で保存
  4. すべて完了したら finish_run で status を更新。

---

## 6. repository.py 詳細

- BenchmarkRepository
  - load_scenario(scenario_id)
  - create_scenario(spec)
  - update_scenario(spec)
  - list_scenarios()
  - delete_scenario(scenario_id)
  - create_run(run_spec)
  - save_results(run_id, results)
  - finish_run(run_id)
  - get_run_with_results(run_id)

---

## 7. agents とのインターフェイス

- PlannerAgent に BenchmarkRepository を渡す。
  - メソッド: get_top_models(task_type, horizon, metric, limit)
- ReporterAgent にも同様の参照を渡し、
  レポート生成の際に cross-framework 結果を取得できるようにする。

