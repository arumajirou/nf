# DB / テーブル設計書: ベンチマーク & LTSM 統合（詳細）

## 1. テーブル一覧

- nf_benchmark_scenarios
- nf_benchmark_scenario_models
- nf_benchmark_runs
- nf_benchmark_results

---

## 2. nf_benchmark_scenarios

- 主キー: scenario_id SERIAL

カラム:
- scenario_id: SERIAL, PK
- name: TEXT, NOT NULL, UNIQUE
- description: TEXT, NULL
- dataset_id: TEXT, NOT NULL
- task_type: TEXT, NOT NULL
- horizon: INTEGER, NULL
- metrics: JSONB, NOT NULL
- created_at: TIMESTAMPTZ, NOT NULL
- updated_at: TIMESTAMPTZ, NOT NULL

インデックス:
- idx_bench_scenarios_task_horizon (task_type, horizon)
- idx_bench_scenarios_dataset (dataset_id)

---

## 3. nf_benchmark_scenario_models

- 主キー: (scenario_id, framework, model_id)

カラム:
- scenario_id: INTEGER, NOT NULL, FK → nf_benchmark_scenarios
- framework: TEXT, NOT NULL
- model_id: TEXT, NOT NULL
- enabled: BOOLEAN, NOT NULL DEFAULT TRUE
- params: JSONB, NULL
- created_at: TIMESTAMPTZ, NOT NULL
- updated_at: TIMESTAMPTZ, NOT NULL

---

## 4. nf_benchmark_runs

- 主キー: run_id SERIAL

カラム:
- run_id: SERIAL, PK
- scenario_id: INTEGER, NOT NULL, FK → nf_benchmark_scenarios
- run_mode: TEXT, NOT NULL
- seed: INTEGER, NOT NULL
- max_runtime_min: REAL, NULL
- status: TEXT, NOT NULL
- started_at: TIMESTAMPTZ, NULL
- finished_at: TIMESTAMPTZ, NULL
- notes: TEXT, NULL

インデックス:
- idx_bench_runs_scenario (scenario_id)
- idx_bench_runs_status (status)

---

## 5. nf_benchmark_results

- 主キー: (run_id, framework, model_id)

カラム:
- run_id: INTEGER, NOT NULL, FK → nf_benchmark_runs
- framework: TEXT, NOT NULL
- model_id: TEXT, NOT NULL
- status: TEXT, NOT NULL
- metrics: JSONB, NULL
- error_message: TEXT, NULL
- extra: JSONB, NULL
- started_at: TIMESTAMPTZ, NULL
- finished_at: TIMESTAMPTZ, NULL

インデックス:
- idx_bench_results_framework_model (framework, model_id)
- idx_bench_results_status (status)

---

## 6. マイグレーション

- Alembic で 1 つの revision として作成。
- ロールバック時は順に DROP TABLE する。
