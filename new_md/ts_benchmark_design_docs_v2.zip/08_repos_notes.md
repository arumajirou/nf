# 各種リポジトリ統合メモ（詳細）

- BasicTS
  - 役割: 公平 TS ベンチマーク基盤。
  - 利用: BasicTSAdapter で公式パイプラインを呼び出し、
    nf_loto データを BasicTS フォーマットに変換して評価。

- TFB
  - 役割: Time Forecasting Benchmark。
  - 利用: 代表的なタスク設定を選び、ロト時系列と整合する条件で評価。

- darts
  - 役割: 多様な TS モデル実装。
  - 利用: DartsAdapter で NBEATS / TFT / Prophet 互換などをラップ。

- sktime
  - 役割: 古典 TS モデルと ML ツールボックス。
  - 利用: SktimeAdapter で ARIMA, ETS などをベンチマークに含める。

- neuralforecast
  - 役割: 既存中核。
  - 利用: NeuralForecastAdapter で cross-framework 比較に組み込む。

- kats
  - 役割: 異常検知・変化点検知。
  - 利用: KatsAdapter で anomaly タスクの評価を行う。

- gift-eval
  - 役割: TSFM / LTSM を含む基礎モデル評価ベンチマーク。
  - 利用: GiftEvalAdapter で nf_loto 側から評価をトリガし、結果を取り込む。

- Large-Time-Series-Model
  - 役割: LTSM の実装集。
  - 利用: LTSMAdapter で代表モデルをロトデータで評価。

