# 詳細実装手順書: ベンチマーク & LTSM 統合

## 手順 0: 前提

- nf_loto_platform リポジトリを clone 済み。
- Python 3.10+ 環境。
- PostgreSQL / MLflow など既存インフラ利用可能。

---

## 手順 1: 依存ライブラリ整理

1. pyproject.toml に bench 用オプショナル依存を追記。
2. 初期フェーズでは darts / sktime / kats のみインストールを必須とし、
   BasicTS / TFB / gift-eval / LTSM は任意とする。

---

## 手順 2: bench パッケージ追加

1. src/nf_loto_platform/bench/ ディレクトリ作成。
2. domain.py, adapters/base.py, repository.py, runner.py を作成。
3. 単体テストで import と基本関数が動作することを確認。

---

## 手順 3: DB マイグレーション

1. Alembic の migration スクリプトを作成し、nf_benchmark_* テーブルを追加。
2. ステージング環境で upgrade / downgrade をテスト。
3. 本番環境への適用時は通常の DB マイグレーション手順に従う。

---

## 手順 4: Repository 実装

1. BenchmarkRepository を実装。
2. シナリオ CRUD / run 作成 / 結果保存の単体テストを書く。
3. テスト用に SQLite やテスト用 PostgreSQL を利用。

---

## 手順 5: DummyAdapter + Runner スモークテスト

1. ダミーアダプタを 2 つ実装（success / failed のパターン）。
2. BenchmarkRunner を実行して、
   - run レコード作成
   - results レコード作成
   まで動くことを確認。

---

## 手順 6: NeuralForecastAdapter + DartsAdapter 実装

1. 既存 model_runner を呼び出す NeuralForecastAdapter を実装。
2. darts の NBEATS など代表モデルを DartsAdapter でラップ。
3. nf_loto の一部データで quick モードベンチマークを実行し、
   メトリクスが取得できることを確認。

---

## 手順 7: BasicTS / TFB / sktime / kats / gift-eval / LTSMAdapter 追加

1. 各フレームワークごとに
   - 依存インストール
   - アダプタ実装
   - 小さなテストシナリオでの検証
   を行う。

---

## 手順 8: agents / Web UI 連携

1. PlannerAgent / ReporterAgent に BenchmarkRepository を注入。
2. Web UI に Benchmark タブを追加し、
   - シナリオ一覧
   - run 実行
   - 結果テーブル
   を表示する。

---

## 手順 9: ドキュメント更新

- README, docs に bench 機能の概要と利用方法を追記。
