# 機能定義書: マルチフレームワーク・ベンチマーク + LTSM 統合（詳細版）

## 1. 機能一覧と概要

- BENCH-001: ベンチマークシナリオ管理
- BENCH-002: フレームワークアダプタ管理
- BENCH-003: ベンチマーク実行オーケストレーション
- BENCH-004: gift-eval 連携
- BENCH-005: LTSM 連携
- BENCH-006: 結果閲覧・比較（Web UI）
- BENCH-007: agents 連携
- BENCH-008: CLI / API インターフェイス
- BENCH-009: ログ・メトリクス出力

---

## 2. BENCH-001 ベンチマークシナリオ管理

2.1 概要
- ベンチマーク実行条件を「シナリオ」として定義・保存・更新・削除する。

2.2 入力項目詳細
- name: シナリオ名（必須、ユニーク）
- description: 自由記述
- dataset_id: nf_loto のテーブルまたはビュー名
- task_type: forecasting / classification / anomaly のいずれか
- horizon: 予測ホライゾン（forecasting の場合は必須）
- metrics: 使用するメトリクスのリスト（例: mae, rmse, smape）
- framework_models: FrameworkModelSpec のリスト

2.3 ユースケース別仕様
- UC1: ロト7 4週先予測の cross-framework 比較
  - dataset_id = nf_loto_panel_weekly
  - task_type = forecasting
  - horizon = 4
  - metrics = ["mae", "rmse", "smape"]
  - framework_models に BasicTS / Darts / NeuralForecast 等を登録。

---

## 3. BENCH-002 フレームワークアダプタ管理

3.1 概要
- 各フレームワークを共通インターフェイスで呼び出すためのアダプタを管理。
- アダプタは name, is_available, supported_tasks, run を実装。

3.2 振る舞い
- is_available が False の場合:
  - BenchmarkRunner は該当フレームワークを skipped として結果を記録。
- supported_tasks に task_type が含まれていない場合:
  - シナリオレベルのバリデーションで警告 or 除外。

---

## 4. BENCH-003 ベンチマーク実行オーケストレーション

4.1 概要
- 1 つのシナリオから複数フレームワークを順次または並列に実行する。

4.2 状態遷移
- nf_benchmark_runs.status:
  - pending → running → success / failed / partial

4.3 エラー処理
- 個別フレームワーク失敗時:
  - そのフレームワークの結果は status=failed とし、error_message を保存。
  - 他フレームワークの実行は継続。

---

## 5. BENCH-004 gift-eval 連携

5.1 機能
- gift-eval による基礎モデル評価を nf_loto 上でトリガし、
  結果を nf_benchmark_results に格納。

5.2 制約
- gift-eval の仕様に合わせたデータ前処理が必要。
- 外部データリーク防止設定は gift-eval のベストプラクティスに従う。

---

## 6. BENCH-005 LTSM 連携

6.1 機能
- Large-Time-Series-Model の代表モデルを nf_loto データで評価。
- fine-tune or zero-shot の 2 モードを想定。

6.2 パラメータ例
- model_id: "TimesNet-large", "iTransformer" など
- mode: "zero_shot" or "finetune"
- max_epochs, learning_rate など LTSM 固有の設定。

---

## 7. BENCH-006 結果閲覧・比較（Web UI）

7.1 要件
- シナリオ一覧表示
- run 実行ボタン
- run ごとの結果（フレームワーク / モデル / メトリクス）表示
- 上位モデルのグラフ表示（棒グラフなど）

---

## 8. BENCH-007 agents 連携

8.1 PlannerAgent
- ベンチマーク結果テーブルから、
  - task_type, horizon, metrics 条件に合う run を検索。
  - メトリクス値によりモデルをソートし、上位モデルを候補に含める。

8.2 ReporterAgent
- ベンチマーク結果から
  - ベストフレームワーク/モデル
  - 他フレームワークとの差
  を抽出し、自然言語レポートに反映。

---

## 9. BENCH-008 CLI / API

9.1 CLI コマンド例
- nf-bench scenario list
- nf-bench scenario create --config scenario.yaml
- nf-bench run --scenario-id 1 --mode quick

9.2 API
- POST /api/bench/runs
- GET /api/bench/runs/{run_id}

---

## 10. BENCH-009 ログ・メトリクス

- ログ出力:
  - ベンチマーク実行毎に JSONL 形式でファイル出力。
- メトリクス:
  - MLflow の run にメトリクス・設定・図表を記録。

