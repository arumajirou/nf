# 詳細実装計画書: ベンチマーク & LTSM 統合

## 1. フェーズ別ゴール

- Phase 0: 設計レビュー完了
- Phase 1: bench 基盤（domain / repository / runner / DB）完成
- Phase 2: NeuralForecastAdapter + DartsAdapter 完成（MVP ベンチマーク）
- Phase 3: BasicTS / TFB のいずれか統合
- Phase 4: sktime / kats / gift-eval / LTSMAdapter 統合
- Phase 5: agents / Web UI 連携完成

## 2. スケジュール例

- Phase 0: 1 週間
- Phase 1: 2 週間
- Phase 2: 2 週間
- Phase 3: 3 週間
- Phase 4: 4 週間
- Phase 5: 2 週間

実際の期間はチーム size と優先度に応じて調整。

## 3. リスク管理

- 外部 API 変更 → アダプタ層で吸収、CI で検出。
- 実行コスト増大 → quick/full モード、モデル数上限で制限。
- ライセンス問題 → OSS ライセンス表を管理し、モードごとに制御。

## 4. 成功指標

- 動作する cross-framework ベンチマークシナリオ数
- AI データサイエンティストがベンチマーク結果を参照した回数
- ロト予測精度の改善度（ベースライン比）
