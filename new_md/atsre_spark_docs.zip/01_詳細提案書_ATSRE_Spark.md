# 01. 詳細提案書 — ATSRE-Spark（Apache Spark 統合 自律型時系列研究環境）

## 1. 文書情報

- 文書名: ATSRE-Spark 詳細提案書
- 版数  : 0.9（ドラフト）
- 作成日: 2025-11-17
- 作成者: （記入欄）

## 2. 背景

提供済みのライブラリ・基盤モデル・エージェント群は、2025 年時点で時系列分野のトップクラスの機能を有している。  
一方で、実務現場では以下のような課題が残存している。

- モデルごとにコードベースが分かれ、**比較・再現性** が低い  
- ハイパラ探索・バックテストが手動で行われ、**研究速度が頭打ち**  
- CPU/GPU/RAM/VRAM/IO などの **リソースコストの見える化** が不十分  
- 因果構造や外生変数を考慮した **堅牢な予測・異常検知** が困難  
- 大規模データ（数億行レベル）を扱う際の **スケーラビリティ** に不安がある

既存設計である ATSRE / ETSRP では、これらを解決するために、PostgreSQL を中核とした  
自律型時系列研究環境のアーキテクチャを定義している。fileciteturn1file1  

本提案書では、これをさらに **Apache Spark を中心とした分散実行基盤に移行する形で拡張** する。  
Spark による ETL・バックテスト・特徴量生成を行い、その上に AutoGluon / Darts / Nixtla / sktime / Merlion 等の  
モデル群と TimeSeriesScientist / TimeCopilot / Argos / anomaly-agent 等のエージェントを統合する。fileciteturn1file0  

## 3. 目的

ATSRE-Spark の目的は以下である。

1. **PostgreSQL 上の任意テーブル** を指定するだけで、Spark 経由で安全かつ効率的にデータ取得・前処理を実行する。  
2. AutoGluon, Darts, Nixtla, sktime, GluonTS, Merlion, PyPOTS, tsflex, tsfel, temporian などを、  
   **単一の統合パイプライン** から呼び出せるようにする。  
3. Chronos-2 / Chronos-Bolt / TimesFM / Moirai / Lag-Llama / Granite / MOMENT / TEMPO / TempoPFN 等の  
   **Time Series Foundation Model (TSFM)** を統一インタフェースで扱う。  
4. BasicTS / TFB / gift-eval / Large-Time-Series-Model / Time-Series-Library を用いた  
   **公平なベンチマーク・評価基盤** を構築する。  
5. TimeSeriesScientist / TimeCopilot / Argos / anomaly-agent などのエージェントフレームワークを活用し、  
   **LLM 駆動の自律ワークフロー（モデル選択〜レポート生成）** を実現する。  
6. CPU/GPU/IO/RAM/VRAM/時間/電力などの **リソース情報をメタデータとして PostgreSQL に保存** し、  
   「精度 × コスト」のパレート最適解を探索できるようにする。  

## 4. 対象 OSS / モデル群（統合一覧）

### 4.1 予測・異常検知ライブラリ

- AutoGluon / autogluon.time_series
- Darts (unit8co/darts)
- sktime
- GluonTS, PyTorch-TS, AutoTS
- Nixtla スタック: statsforecast / neuralforecast / mlforecast / hierarchicalforecast / utilsforecast / coreforecast
- Salesforce Merlion
- neural_prophet, UniTS, Time-LLM, Time-MoE
- Mycodo（実環境センサ系統合のリファレンス）
- tsfel, temporian, tsflex, seglearn, matrixprofile / matrixprofile-ts, time-series-autoencoder などの特徴量・パターン抽出系

### 4.2 Foundation Models / TSFM

- amazon/chronos-2, amazon/chronos-t5-large, autogluon/chronos-bolt-base
- google/timesfm-2.0 / 2.5 系
- ibm-granite/granite-timeseries-ttm-r2
- ant-intl/Falcon-TST_Large
- AutonLab/MOMENT-1-large, Melady/TEMPO, AutoML-org/TempoPFN
- time-series-foundation-models/Lag-Llama
- Salesforce/moirai-1.1-R-large
- NX-AI/TiRex など

### 4.3 ベンチマーク / 評価フレームワーク

- GestaltCogTeam/BasicTS
- decisionintelligence/TFB
- SalesforceAIResearch/gift-eval
- thuml/Large-Time-Series-Model
- thuml/Time-Series-Library

### 4.4 エージェント / LLM 連携

- TimeSeriesScientist（5 エージェント構成）
- TimeCopilot
- Argos (Microsoft)
- anomaly-agent

## 5. 全体アーキテクチャ（Spark 統合版）

```mermaid
flowchart LR
    subgraph U[ユーザ / システム利用者]
        CLI[CLI / Notebook]
        CHAT[LLM チャット UI]
    end

    subgraph L[LLM & エージェント層]
        ORCH[Orchestrator Agent
(LangGraph)]
        CUR[Curator Agent
(前処理・品質診断)]
        CAUSAL[Causal Analyst
(causal-learn)]
        PLAN[Planner Agent
(戦略立案)]
        FORE[Forecaster Agent
(学習・推論)]
        REP[Reporter Agent
(レポート生成)]
    end

    subgraph S[Spark クラスタ]
        DRV[Driver Program
(PySpark)]
        CM[Cluster Manager
(K8s/YARN/Standalone)]
        EX1[Executor 1]
        EX2[Executor 2]
        EXN[Executor N]
    end

    subgraph DB[(PostgreSQL)]
        RAW[(業務データスキーマ)]
        META[(atsre_meta スキーマ
実験・モデル・リソース)]
    end

    U --> CHAT --> ORCH
    U --> CLI --> ORCH

    ORCH --> CUR --> DRV
    ORCH --> CAUSAL
    ORCH --> PLAN
    ORCH --> FORE
    ORCH --> REP

    DRV --> CM --> EX1
    CM --> EX2
    CM --> EXN

    EX1 -->|JDBC 読み込み/書き込み| RAW
    EX2 --> RAW
    EXN --> RAW

    FORE -->|モデル実行結果/リソース| META
    CAUSAL --> META
    PLAN --> META
    CUR --> META
    REP --> META
```

- Spark クラスタは **データロード・前処理・特徴量生成・バックテスト** を主に担当。
- 個々のモデル学習は、Spark Executor 上で python ランタイム（PyTorch / JAX / NumPy）を起動し、  
  Darts / Nixtla / AutoGluon 等を呼び出す形で実装する。  
- LLM エージェントは、Meta DB（`atsre_meta`）を定期的に参照し、自律的に戦略変更・モデル再選択を行う。fileciteturn1file1  

## 6. スコープ

### 6.1 初期フェーズで実現する範囲

1. Spark ベースの Postgres 連携・前処理パイプライン  
2. AutoGluon / Darts / Nixtla / sktime / Merlion / 一部 TSFM の Spark 経由実行  
3. BasicTS / TFB / gift-eval によるベンチマークジョブの Spark 実装  
4. TimeSeriesScientist / TimeCopilot を基盤とした LLM エージェント層（最小構成）  
5. リソースメトリクス（CPU/GPU/RAM/VRAM/IO/時間）の DB 永続化  

### 6.2 将来的な拡張

- Spark Structured Streaming を利用した **オンライン異常検知・早期警戒システム**  
- pgvector 等による **実験レポートのベクトル検索 + RAG**  
- 時系列 DB（TimescaleDB など）との二層構成  
- 複数クラスタ・複数クラウドへの展開（マルチテナント化）  

## 7. 非機能要件

- スケーラビリティ: 1 億行規模のログデータに対して、日次バッチでバックテストを完走可能
- 再現性: 任意の実験は `experiment_id` / `run_id` から完全に再現可能
- 可観測性: リソースログとメトリクスログから、モデルごとのコスト/精度を時系列で追跡可能
- 信頼性: 失敗したジョブは Planner による自動再計画（リトライ戦略変更）で復旧
- セキュリティ: Spark からの DB アクセス権限は SELECT/INSERT に限定し、DDL/DROP を禁止

## 8. ロードマップ（例）

```mermaid
gantt
    dateFormat  YYYY-MM-DD
    title       ATSRE-Spark ロードマップ（例）

    section Phase 1: 基盤整備
    要件定義・DB/メタスキーマ設計      :done,   des1, 2025-11-01, 2025-12-15
    Spark 接続・データロード PoC       :active, sp1, 2025-12-01, 2026-01-15

    section Phase 2: モデル統合
    AutoGluon/Darts/Nixtla ラッパ実装   :sp2, 2026-01-10, 2026-02-20
    TSFM ラッパ (Chronos/TimesFM/Moirai):sp3, 2026-02-01, 2026-03-10

    section Phase 3: エージェント層
    TimeSeriesScientist/TimeCopilot 統合:ag1, 2026-03-01, 2026-04-15
    Argos/anomaly-agent 統合           :ag2, 2026-03-15, 2026-05-01

    section Phase 4: ベンチマーク・本格運用
    BasicTS/TFB/gift-eval ベンチ構築     :bench1,2026-04-01, 2026-05-15
    運用設計・ダッシュボード整備       :op1,   2026-05-01, 2026-06-01
```
