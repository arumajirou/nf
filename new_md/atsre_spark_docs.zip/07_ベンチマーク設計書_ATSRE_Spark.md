# 07. ベンチマーク設計書 — ATSRE-Spark

## 1. 目的

- 提供されたライブラリ・TSFM・エージェントを対象に、
  - 精度
  - 計算コスト（CPU/GPU 時間・メモリ・IO）
  - 安定性（再現性・分散）
  を公平に比較するためのベンチマーク設計を定義する。fileciteturn1file0  

## 2. 対象コンポーネント

- ライブラリ:
  - AutoGluon, Darts, Nixtla stack, sktime, GluonTS, Merlion, PyTorch-TS, AutoTS, UniTS, Time-LLM, Time-MoE など
- TSFM:
  - Chronos 系, TimesFM 系, Moirai, Lag-Llama, Granite, MOMENT, TEMPO, TempoPFN, TiRex 等
- エージェント:
  - TimeSeriesScientist, TimeCopilot, Argos, anomaly-agent

## 3. ベンチマークスイート構成

### 3.1 データセットクラス

- クラス A: 単変量・短系列（例: 日次 1 年分程度）
- クラス B: 単変量・長系列（例: 日次 10 年以上）
- クラス C: 多変量・小規模（数十変数 × 数千ステップ）
- クラス D: 多変量・大規模（数百変数 × 数万ステップ）
- クラス E: イベントドリブン / 不規則サンプリング（ログ・センサなど）

### 3.2 評価指標

- 精度系: MAPE, SMAPE, RMSE, MAE, CRPS, MSIS
- 異常検知系: Precision@k, Recall@k, F1, AUROC
- コスト系: CPU/GPU 時間、ピークメモリ、IO, Spark タスク時間
- 安定性: seed を変えた場合のメトリクス分散

## 4. Spark ベース実行フロー

```mermaid
flowchart LR
    CONF[ベンチマーク定義
(ts_benchmark_suite)] --> GEN[ベンチケース生成]
    GEN --> SPARK[Spark Benchmark Job]
    SPARK --> RUNS[複数 ts_run レコード作成]
    SPARK --> METRIC[ts_metric 更新]
    SPARK --> RES[ts_run_resource 更新]
    METRIC --> LB[リーダーボードビュー]
    RES --> LB
```

- `ts_benchmark_suite` テーブル例:
  - `suite_id`, `name`, `description`, `dataset_list`, `model_list`, `metric_list`, `created_at`

## 5. リーダーボード表示要件

- フィルタ:
  - データセット, モデル, タスク種別, 日付範囲
- 指標:
  - 主指標（例: MAPE）でソート
  - 参考としてコスト指標（例: GPU 秒 / RMSE）も表示
- 出力形式:
  - Web ダッシュボード（Grafana/Metabase 等）
  - Notebook 用 SQL テンプレート

## 6. エージェント連携

- Planner Agent は、リーダーボードの結果から「このデータセットクラスに対して歴史的に良かったモデル」を検索し、
  初期候補として採用する。
- TimeCopilot / TimeSeriesScientist は、自然言語で
  「このデータに似たケースではどのモデルが良かったか？」
  と質問されたときに、ベンチマーク結果を根拠として回答する。fileciteturn1file0  

