# 04. DB テーブル定義書 — ATSRE-Spark

## 1. 概要

本書では、`atsre_meta` スキーマに含まれるメタデータテーブルの論理定義および DDL 例を示す。  
実験・モデル・ラン・リソース・評価指標・予測結果・因果グラフ・異常イベント・エージェントログを対象とする。fileciteturn1file1  

## 2. テーブル一覧

| 論理名           | 物理名              | 概要                                 |
|------------------|---------------------|--------------------------------------|
| データセット     | ts_dataset          | データセット（元テーブル）定義      |
| 実験             | ts_experiment       | 実験（Experiment）                   |
| モデル           | ts_model            | モデル定義                           |
| ラン             | ts_run              | 実験 × モデル × 設定の実行単位      |
| ランリソース     | ts_run_resource     | ラン単位の集約リソース情報           |
| リソースログ     | ts_resource_log     | 高頻度リソースログ（任意）          |
| 評価指標         | ts_metric           | メトリクス                          |
| 予測結果         | ts_forecast         | 予測値・予測区間                     |
| アンサンブル     | ts_ensemble         | アンサンブル定義                     |
| アンサンブル構成 | ts_ensemble_member  | アンサンブル構成要素                 |
| 因果グラフ       | ts_causal_graph     | 因果グラフ                           |
| 因果効果         | ts_causal_effect    | 効果推定結果                         |
| 異常イベント     | ts_anomaly_event    | 異常検知結果                         |
| エージェントセッション | ts_agent_session | エージェントセッション              |
| エージェントステップ   | ts_agent_step    | セッション内ステップ                 |

## 3. DDL 例（抜粋）

### 3.1 ts_dataset

```sql
CREATE TABLE atsre_meta.ts_dataset (
    dataset_id      BIGSERIAL PRIMARY KEY,
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    source_schema   VARCHAR(255) NOT NULL,
    source_table    VARCHAR(255) NOT NULL,
    time_column     VARCHAR(255) NOT NULL,
    target_column   VARCHAR(255) NOT NULL,
    id_columns      JSONB,
    freq            VARCHAR(32),
    row_count       BIGINT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### 3.2 ts_experiment

```sql
CREATE TABLE atsre_meta.ts_experiment (
    experiment_id   BIGSERIAL PRIMARY KEY,
    dataset_id      BIGINT NOT NULL REFERENCES atsre_meta.ts_dataset(dataset_id),
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    task_type       VARCHAR(64) NOT NULL, -- forecast/anomaly/causal
    config          JSONB,
    created_by      VARCHAR(255),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### 3.3 ts_model

```sql
CREATE TABLE atsre_meta.ts_model (
    model_id        BIGSERIAL PRIMARY KEY,
    framework       VARCHAR(128) NOT NULL, -- autogluon/darts/nixtla/sktime/merlion/tsfm
    model_type      VARCHAR(128) NOT NULL, -- Chronos-2/NBEATS/ARIMA など
    version         VARCHAR(64),
    hyperparams     JSONB,
    artifact_path   TEXT,
    is_tsfm         BOOLEAN NOT NULL DEFAULT FALSE,
    created_by_agent BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### 3.4 ts_run

```sql
CREATE TABLE atsre_meta.ts_run (
    run_id          BIGSERIAL PRIMARY KEY,
    experiment_id   BIGINT NOT NULL REFERENCES atsre_meta.ts_experiment(experiment_id),
    model_id        BIGINT NOT NULL REFERENCES atsre_meta.ts_model(model_id),
    spark_app_id    VARCHAR(128),   -- Spark Application ID
    status          VARCHAR(32) NOT NULL, -- pending/running/success/failed
    random_seed     INTEGER,
    started_at      TIMESTAMPTZ,
    ended_at        TIMESTAMPTZ,
    remark          TEXT
);
```

### 3.5 ts_run_resource

```sql
CREATE TABLE atsre_meta.ts_run_resource (
    run_resource_id BIGSERIAL PRIMARY KEY,
    run_id          BIGINT NOT NULL REFERENCES atsre_meta.ts_run(run_id),
    node_name       VARCHAR(255),
    cpu_usage_avg   NUMERIC(5,2),
    cpu_usage_max   NUMERIC(5,2),
    gpu_time_sec    NUMERIC(12,2),
    gpu_vram_max_gb NUMERIC(8,2),
    ram_max_gb      NUMERIC(8,2),
    io_read_mb      NUMERIC(12,2),
    io_write_mb     NUMERIC(12,2),
    train_time_sec  NUMERIC(12,2),
    infer_time_sec  NUMERIC(12,2)
);
```

### 3.6 ts_metric

```sql
CREATE TABLE atsre_meta.ts_metric (
    metric_id       BIGSERIAL PRIMARY KEY,
    run_id          BIGINT NOT NULL REFERENCES atsre_meta.ts_run(run_id),
    dataset_role    VARCHAR(32) NOT NULL, -- train/val/test/backtest
    metric_name     VARCHAR(64) NOT NULL,
    metric_value    NUMERIC(20,8) NOT NULL,
    horizon         INTEGER,
    segment         VARCHAR(255)
);
```

### 3.7 ts_forecast

```sql
CREATE TABLE atsre_meta.ts_forecast (
    forecast_id     BIGSERIAL PRIMARY KEY,
    run_id          BIGINT NOT NULL REFERENCES atsre_meta.ts_run(run_id),
    series_key      JSONB NOT NULL,
    timestamp       TIMESTAMPTZ NOT NULL,
    horizon         INTEGER NOT NULL,
    y_hat           DOUBLE PRECISION NOT NULL,
    y_hat_lower     DOUBLE PRECISION,
    y_hat_upper     DOUBLE PRECISION,
    is_ensemble     BOOLEAN NOT NULL DEFAULT FALSE
);
```

## 4. ER 図

```mermaid
erDiagram
    TS_DATASET ||--o{ TS_EXPERIMENT : has
    TS_EXPERIMENT ||--o{ TS_RUN : includes
    TS_MODEL ||--o{ TS_RUN : used_in
    TS_RUN ||--o{ TS_RUN_RESOURCE : profiled_by
    TS_RUN ||--o{ TS_METRIC : evaluated_by
    TS_RUN ||--o{ TS_FORECAST : produces
    TS_EXPERIMENT ||--o{ TS_ENSEMBLE : defines
    TS_ENSEMBLE ||--o{ TS_ENSEMBLE_MEMBER : contains
    TS_RUN ||--o{ TS_ENSEMBLE_MEMBER : component_of
    TS_DATASET ||--o{ TS_CAUSAL_GRAPH : has
    TS_CAUSAL_GRAPH ||--o{ TS_CAUSAL_EFFECT : yields
    TS_RUN ||--o{ TS_ANOMALY_EVENT : detects
    TS_AGENT_SESSION ||--o{ TS_AGENT_STEP : consists_of
```

