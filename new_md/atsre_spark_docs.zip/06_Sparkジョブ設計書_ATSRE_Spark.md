# 06. Spark ジョブ設計書 — ATSRE-Spark

## 1. Spark クラスタ構成（論理）

```mermaid
graph LR
    U[ATSRE アプリケーション
(REST/Agent)] --> SUBMIT[spark-submit API]

    SUBMIT --> DRV[Driver Pod]
    DRV --> CM[K8s/YARN Scheduler]

    CM --> EX1[Executor Pod 1]
    CM --> EX2[Executor Pod 2]
    CM --> EXN[Executor Pod N]

    EX1 --> PG[(PostgreSQL)]
    EX2 --> PG
    EXN --> PG
```

- バージョン想定: Apache Spark 3.5.x
- 実行モード: Kubernetes もしくは standalone cluster
- 言語: PySpark (主要), 必要に応じて Scala ジョブも許容

## 2. ジョブ種別

| ジョブ種別 ID | 種別           | 概要                                             |
|---------------|----------------|--------------------------------------------------|
| J-01          | DataProfile    | 業務テーブルの統計情報・品質診断                |
| J-02          | FeatureGen     | 特徴量生成（ローリング・ラグ・カレンダーなど）  |
| J-03          | Train          | モデル学習（AutoGluon/Darts/Nixtla/sktime 等）  |
| J-04          | Forecast       | 予測実行                                         |
| J-05          | Benchmark      | BasicTS/TFB/gift-eval/TS-Library ベンチマーク   |
| J-06          | Anomaly        | 異常検知ジョブ（Merlion/Argos/anomaly-agent）   |
| J-07          | Causal         | 因果探索ジョブ（causal-learn）                  |

## 3. spark-submit パラメータ標準

- 共通ルール:
  - アプリ名: `atsre-{job_type}-{experiment_id}-{run_id}`
  - コンフィグ: `ts_run.spark_app_id` に実行 ID を保存
- 例: Train ジョブ

```bash
spark-submit   --master k8s://https://kubernetes.default.svc   --deploy-mode cluster   --name "atsre-train-EXP123-RUN456"   --conf spark.executor.instances=8   --conf spark.executor.memory=8g   --conf spark.executor.cores=4   atsre_train_job.py     --experiment-id 123     --run-id 456
```

## 4. ジョブ内部構造（Train ジョブ）

```mermaid
flowchart TD
    A[引数パース
(experiment_id, run_id)] --> B[Meta DB から設定読込]
    B --> C[SparkSession 初期化]
    C --> D[JDBC で学習データ読み込み]
    D --> E[特徴量生成 / 前処理]
    E --> F[Driver or Executor でモデル学習]
    F --> G[モデルアーティファクト保存]
    F --> H[評価メトリクス算出]
    G --> I[ts_model 更新]
    H --> J[ts_metric への書き込み]
    F --> K[ts_run_resource の計測値集約]
```

## 5. リソースとパフォーマンスチューニング

- Executor 数・メモリ・コア数は、データサイズ・モデル種類に応じて Planner Agent が提案し、
  ジョブ送信時に動的に設定できるようにする。
- 特に TSFM モデルは GPU 利用を前提とする場合が多いため、GPU ノードプールと CPU ノードプールを分離し、
  Spark の resource profile で制御する。

