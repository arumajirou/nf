# 03. 詳細機能設計仕様書 — ATSRE-Spark

## 1. アプリケーションレイヤ構成

```mermaid
graph TD
    subgraph API[API / UI Layer]
        REST[REST API]
        NB[Notebook / CLI]
        CHAT[LLM Chat UI]
    end

    subgraph APP[Application Services]
        EXP[Experiment Service]
        DATA[Dataset Service]
        RUN[Run Orchestrator]
        BENCH[Benchmark Service]
        CAUS[ Causal Service ]
        ANOM[ Anomaly Service ]
    end

    subgraph AG[Agent Layer]
        ORCH[Orchestrator Agent]
        CUR[Curator]
        PLAN[Planner]
        FORE[Forecaster]
        REP[Reporter]
        CAUAG[Causal Analyst]
    end

    subgraph SP[Spark Cluster]
        DRV[Driver]
        EXE1[Executor 1]
        EXE2[Executor 2]
        EXEN[Executor N]
    end

    subgraph DB[(PostgreSQL)]
        RAW[(業務スキーマ)]
        META[(atsre_meta)]
    end

    REST --> EXP
    NB --> EXP
    CHAT --> ORCH
    ORCH --> APP

    APP --> DRV
    DRV --> EXE1
    DRV --> EXE2
    DRV --> EXEN

    EXE1 --> RAW
    EXE2 --> RAW
    EXEN --> RAW

    APP --> META
    AG --> META
```

## 2. Spark データ取得・前処理モジュール

### 2.1 PostgresTimeSeriesLoader (Spark版)

- 実装言語: Python (PySpark)
- 役割:
  - `spark.read.format("jdbc")` を用いて PostgreSQL からテーブルをロード
  - 指定された time 列で日付範囲フィルタ、id 列でパーティション分割
  - 長形式 (item_id, timestamp, target, covariates...) に変換

疑似コード:

```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

def create_spark(app_name: str) -> "SparkSession":
    return (
        SparkSession.builder
        .appName(app_name)
        .config("spark.jars.packages", "org.postgresql:postgresql:42.7.2")
        .getOrCreate()
    )

def load_timeseries_from_pg(
    spark: "SparkSession",
    jdbc_url: str,
    table: str,
    user: str,
    password: str,
    partition_column: str,
    lower_bound: int,
    upper_bound: int,
    num_partitions: int,
):
    df = (
        spark.read.format("jdbc")
        .option("url", jdbc_url)
        .option("dbtable", table)
        .option("user", user)
        .option("password", password)
        .option("driver", "org.postgresql.Driver")
        .option("partitionColumn", partition_column)
        .option("lowerBound", lower_bound)
        .option("upperBound", upper_bound)
        .option("numPartitions", num_partitions)
        .load()
    )
    return df
```

### 2.2 特徴量生成ジョブ

- Spark 上で実行されるバッチジョブ。
- 処理例:
  - ローリング平均・分散・最小値・最大値
  - ラグ特徴量（1, 7, 30 ステップなど）
  - カレンダー特徴（曜日・月・四半期・祝日フラグ 等）

```mermaid
flowchart LR
    RAW[(RAW テーブル)] --> ETL[Spark ETL Job]
    ETL --> FEATS[特徴量テーブル
(ts_features)]
    FEATS --> TRAIN[モデル学習ジョブ]
```

## 3. モデル実行アダプター

### 3.1 抽象インタフェース

```python
class BaseTSModelAdapter(Protocol):
    framework: str
    model_name: str

    def fit(self, train_df, **kwargs) -> None: ...
    def predict(self, horizon: int, **kwargs) -> "pd.DataFrame": ...
    def save(self, path: str) -> None: ...
    @classmethod
    def load(cls, path: str) -> "BaseTSModelAdapter": ...
```

### 3.2 Spark との連携パターン

- パターン A: Driver 学習
  - Spark で前処理 → `.toPandas()` で Driver に収集 → Darts / AutoGluon 等で学習
  - 小〜中規模データ（数百万行程度）向け
- パターン B: Executor UDF 学習
  - `mapInPandas` / Pandas UDF を用いて Executor 上でモデル学習
  - id でグルーピングし、シリーズごとに独立学習
  - 並列度を Spark が制御

## 4. エージェント層詳細

### 4.1 Orchestrator Agent

- LangGraph もしくは類似フレームワークを利用し、以下を制御:
  - 「テーブル指定 → データプロファイル → 因果探索 → モデル選定 → Spark ジョブ発行 → 結果登録」の一連の DAG
- 失敗時リトライロジック:
  - Spark ジョブの失敗理由（OOM, Timeout 等）を解析し、Planner に再計画を依頼

### 4.2 Planner Agent

- 入力:
  - Curator レポート（データ特性）
  - Causal Analyst レポート（DAG）
  - 過去の `ts_metric`, `ts_run_resource`（類似データの結果）
- 出力:
  - 実験計画 (`ts_experiment.config` に JSON として保存)
  - モデル候補 + ハイパパラ + リソース制約

### 4.3 Forecaster Agent

- Spark ジョブのテンプレート（`spark-submit` 用）を生成
- `ts_run` レコードを作成し、`status` を `running` に更新
- ジョブ完了後に `ts_metric`, `ts_forecast`, `ts_run_resource` を更新

## 5. エラー処理・自己修復戦略

```mermaid
sequenceDiagram
    participant F as Forecaster Agent
    participant SP as Spark
    participant DB as Meta DB
    participant P as Planner Agent

    F->>SP: 学習ジョブ送信
    SP-->>F: 失敗 (OutOfMemoryError)
    F->>DB: ts_run.status = "failed" + エラーログ
    F->>P: 再計画要求 (エラー内容付き)
    P->>P: エラー解析 (resource_logs)
    P-->>DB: 新しい config を ts_experiment に保存
    P-->>F: 再実行指示 (より小さいモデル / データ削減)
```

- Out of Memory 発生時:
  - horizon 短縮 / バッチサイズ削減 / モデルサイズ Small 化
- 実行時間超過時:
  - モデル候補数削減 / 学習イテレーション数削減

