# 02. 機能定義書 — ATSRE-Spark

## 1. 文書情報

- 文書名: ATSRE-Spark 機能定義書
- 版数  : 0.9（ドラフト）

## 2. 機能一覧

### 2.1 機能一覧テーブル（上位レベル）

| ID   | カテゴリ         | 機能名                                      | 概要                                                    | 優先度 |
|------|------------------|---------------------------------------------|---------------------------------------------------------|--------|
| F-01 | データ取得       | PostgreSQL テーブル取得                     | JDBC 経由で Spark から任意テーブルをロード             | ★★★★★ |
| F-02 | スキーマ推論     | 時系列スキーマ自動推論                     | time / id / target / covariate 列の自動推定            | ★★★★★ |
| F-03 | 前処理           | 欠損補完・外れ値処理                        | Curator Agent + tsfel/temporian/tsflex による処理      | ★★★★★ |
| F-04 | 特徴量生成       | Spark ベース特徴量生成                     | ローリング統計・ラグ特徴・カレンダー特徴など           | ★★★★☆ |
| F-05 | モデルカタログ   | モデル群メタ管理                            | 利用可能なモデル・TSFM を DB でカタログ管理           | ★★★★☆ |
| F-06 | 自動モデル選択   | LLM 駆動モデル選択                          | Planner Agent が候補モデルを選定                       | ★★★★★ |
| F-07 | モデル学習       | Spark 実行コンテキストでの学習             | Executor 上で AutoGluon/Darts/Nixtla/sktime 学習      | ★★★★★ |
| F-08 | 予測生成         | 単体予測                                   | horizon 指定でポイント予測・区間予測                   | ★★★★★ |
| F-09 | アンサンブル     | アンサンブル予測                           | Weighted / Stacking / Meta-Learner                     | ★★★★☆ |
| F-10 | 評価             | 統一評価・ベンチマーク                      | BasicTS/TFB/gift-eval/TS-Library                       | ★★★★★ |
| F-11 | 異常検知         | 異常検知パイプライン                        | Merlion + Argos + anomaly-agent                        | ★★★★☆ |
| F-12 | 因果解析         | 因果グラフ推定・効果推定                    | causal-learn + DoWhy                                   | ★★★☆☆ |
| F-13 | リソース計測     | リソース・性能ログ                         | psutil + NVML + Spark メトリクス                      | ★★★★★ |
| F-14 | メタデータ管理   | 実験・モデル・予測・因果・異常メタ管理      | `atsre_meta` スキーマで一元管理                         | ★★★★★ |
| F-15 | エージェント UI  | 自然言語インタフェース                     | TimeSeriesScientist/TimeCopilot ベース                 | ★★★★☆ |
| F-16 | Spark スケジューラ | Spark ジョブ管理                           | Spark Submit / Airflow / ArgoWorkflow 連携            | ★★★★☆ |
| F-17 | ベンチマーク管理 | データセット・スコアのリーダーボード       | ベンチ結果の可視化・フィルタリング                     | ★★★★☆ |

## 3. 機能定義詳細（抜粋）

### F-01: PostgreSQL テーブル取得

- 入力:
  - `schema_name`, `table_name`
  - 接続情報（接続プール名または DSN）
- 処理:
  - Spark JDBC を用いて、パーティションカラム（time または id）で分割読み込み
  - スキーマ情報を `ts_dataset` テーブルに登録
- 出力:
  - Spark DataFrame（長形式: id, timestamp, target, covariates...）

```mermaid
sequenceDiagram
    participant U as User
    participant A as Orchestrator Agent
    participant S as Spark Driver
    participant DB as PostgreSQL

    U->>A: テーブル名・期間・ターゲット指定
    A->>S: ジョブ設定 (schema.table, where 条件)
    S->>DB: JDBC SELECT (パーティション指定)
    DB-->>S: データバッチ
    S-->>A: DataFrame ハンドル（内部 ID）
```

### F-03: 前処理・品質診断

- 欠損値パターン分析（時間方向 / id 方向）
- 外れ値検知（IQR, z-score, matrix profile ベースなど）
- 季節性・トレンド検出（ADF/KPSS, STL 分解 等）
- Argos / anomaly-agent 連携による「ドメインルール生成」オプション

### F-06: LLM 駆動モデル選択

- 入力:
  - データプロファイル（季節性、トレンド強度、系列数、長さ、共変量数）
  - 因果グラフから抽出されたドライバ変数情報
  - 過去実験の成功/失敗パターン（類似データセット）
- 出力:
  - 実行候補モデルリスト（例: Chronos-2, TimesFM-2.5, NHITS, AutoARIMA）
  - 各モデルの採用理由（テキスト）
  - 探索ハイパパラメータ範囲

### F-10: ベンチマーク

- BasicTS / TFB / gift-eval / Time-Series-Library を Spark ジョブとして実行
- 統一されたベンチ設定:
  - 同一の train/test split, horizon, frequency
  - 共通の評価指標: MAPE, SMAPE, RMSE, CRPS, MSIS 等
- 結果は `ts_metric`, `ts_forecast`, `ts_benchmark_suite`（後述）に格納

### F-13: リソース計測

- Spark メトリクス:
  - ジョブ/ステージ/タスク単位の実行時間
  - Executor ごとの CPU 時間・メモリ使用量
- モデルプロセスメトリクス:
  - psutil / NVML による Python プロセス単位の CPU/GPU/RAM/VRAM/IO
- 保存先:
  - `ts_run_resource`（集約値）
  - `ts_resource_log`（高頻度ログ：オプションで TimescaleDB ハイパーテーブル）

