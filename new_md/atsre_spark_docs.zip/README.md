# ATSRE-Spark ドキュメント一式

本ディレクトリには、Apache Spark を中核とした **自律型時系列研究環境 (ATSRE-Spark)** の設計資料を格納しています。  
全て Markdown + Mermaid で記載されており、PostgreSQL をメタデータストアとしたエージェント型アーキテクチャ、  
AutoGluon / Nixtla / Darts / sktime / Merlion / TimeSeriesScientist / TimeCopilot / Argos / anomaly-agent などの  
ライブラリ・エージェントを統合した形で整理しています。

## 含まれるファイル

1. `01_詳細提案書_ATSRE_Spark.md`  
2. `02_機能定義書_ATSRE_Spark.md`  
3. `03_詳細機能設計仕様書_ATSRE_Spark.md`  
4. `04_DBテーブル定義書_ATSRE_Spark.md`  
5. `05_RDB設計書_ATSRE_Spark.md`  
6. `06_Sparkジョブ設計書_ATSRE_Spark.md`  
7. `07_ベンチマーク設計書_ATSRE_Spark.md`  

DB 接続想定（開発デフォルト）:

```text
host     : localhost
port     : 5432
database : postgres
user     : postgres
password : z
```

Spark は主に以下用途で利用します。

- PostgreSQL からの大規模データロード・前処理・特徴量生成
- 大規模バックテスト・交差検証の分散実行
- 一部モデル（軽量な統計モデル群）の Spark 内分散推論
