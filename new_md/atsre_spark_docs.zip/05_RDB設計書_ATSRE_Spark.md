# 05. RDB 設計書 — ATSRE-Spark

## 1. スキーマ構成

- 業務データスキーマ: 任意（例: `public`, `biz`, `iot`）
- メタデータスキーマ: `atsre_meta`
- オプション拡張:
  - 高頻度ログ用: TimescaleDB 拡張を導入し、`ts_resource_log` をハイパーテーブル化
  - ベクトル検索用: pgvector 拡張を導入し、レポート埋め込みを保存する `ts_report_embedding` を追加

## 2. 正規化方針

- 実験・モデル・ラン・メトリクス・予測結果は第 3 正規形を基本とする。
- ライブラリ固有のハイパパラ・因果グラフ構造・エージェント思考ログは JSONB で保持し、
  スキーマ変更なしに機能追加できるようにする。fileciteturn1file1  

## 3. インデックス戦略

- 高頻度参照カラムにインデックスを付与:
  - `ts_run (experiment_id, status, started_at)`
  - `ts_metric (run_id, metric_name)`
  - `ts_forecast (run_id, timestamp)`
  - `ts_anomaly_event (run_id, start_time)`
- Spark からの参照を考慮した複合インデックス:
  - `ts_metric (metric_name, metric_value)` → ベンチマークのランキング用
  - `ts_run_resource (run_id)` → JOIN 用

## 4. パーティショニング

- 大規模環境では、以下の方針でパーティショニングを検討:
  - `ts_forecast`: `timestamp` または `run_id` 単位で RANGE パーティション
  - `ts_resource_log`: `log_time` 単位で RANGE パーティション（TimescaleDB 使用時はハイパーテーブル）

```mermaid
graph TD
    subgraph Partitions
        F2025Q1[ts_forecast_2025_q1]
        F2025Q2[ts_forecast_2025_q2]
        F2025Q3[ts_forecast_2025_q3]
    end

    MASTER[(ts_forecast_master)] --> F2025Q1
    MASTER --> F2025Q2
    MASTER --> F2025Q3
```

## 5. Spark との連携パターン

- Spark 側では `dbtable` としてパーティションテーブルではなく **親テーブル** を指定し、
  PostgreSQL がパーティションへルーティングするようにする。
- 実験・ラン・メトリクスなどのメタテーブルに対しては、Spark で直接集計クエリを投げ、
  ベンチマークレポートをまとめて生成する。

## 6. 可用性・バックアップ

- RPO/RTO 要件に応じ、以下を検討:
  - PostgreSQL の同期レプリカ
  - メタデータスキーマのみの論理バックアップ（`pg_dump -n atsre_meta`）
  - S3 等への定期スナップショット
